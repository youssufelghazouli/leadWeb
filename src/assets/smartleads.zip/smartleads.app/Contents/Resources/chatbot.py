import json
import requests
import re

# DeepSeek API configuration
DEEPSEEK_API_KEY = "sk-a2f4a026e0094d85b9cdac44ff050b80"
DEEPSEEK_API_URL = "https://api.deepseek.com/v1/chat/completions"
HEADERS = {
    "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
    "Content-Type": "application/json"
}

def call_deepseek_api(prompt):
    """
    Calls the DeepSeek API to process the given prompt.
    
    Args:
        prompt (str): The user's input or question about the app.
    
    Returns:
        str: The API's cleaned response content or an error message.
    """
    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert assistant for the SmartSearch Leads app, designed to help clients generate and manage leads. "
                "Your role is to provide clear, concise, and actionable guidance on using the app’s features: "
                "1. Instagram Post/Ad Interaction Lead Search: Finds leads based on likes, comments, and posts on competitors’ Instagram content (e.g., realtors, housing ads). "
                "2. Local B2B Business Search: Identifies nearby businesses for partnerships or clients, providing name, contact, and address details. "
                "3. Intent Lead Search: Finds leads based on social media interactions (posts, comments) showing intent related to client keywords (e.g., 'sold houses'). "
                "4. Consent Management: Sends consent requests to B2C leads via Instagram or email, ensuring legal compliance, with a dedicated section for manual input. "
                "5. Statistics Dashboard: Displays lead data (requested, consents granted/denied/pending) with success rate summaries. "
                "All leads are location-based, fresh, intent-specific, and exclusive to limited clients per region. "
                "When asked, generate 3-4 search query examples for Instagram or Intent Lead Search tailored to the user’s occupation, needs, or keywords. "
                "For other features, provide step-by-step instructions with examples. "
                "Format responses with: "
                "- An introductory sentence. "
                "- Numbered lists (e.g., '1. Step one\n2. Step two') for steps or queries. "
                "- Bullet points (e.g., '- Item one\n- Item two') for feature details or tips. "
                "Keep responses user-friendly, concise, and specific to the SmartSearch Leads app. "
                "Do not include any HTML, code fences, or styling suggestions in the response."
            )
        },
        {"role": "user", "content": prompt[:10000]}
    ]
    
    payload = {
        "model": "deepseek-chat",
        "messages": messages,
        "max_tokens": 4096,
        "temperature": 0.7
    }
    
    try:
        response = requests.post(DEEPSEEK_API_URL, headers=HEADERS, json=payload)
        response.raise_for_status()
        content = response.json()["choices"][0]["message"]["content"].strip()
        # Clean any potential code fences or styling notes
        content = re.sub(r"```html|```|'''html|'''", "", content)
        content = re.sub(r"Suggest styling:.*?$", "", content, flags=re.MULTILINE)
        return content.strip()
    except requests.exceptions.HTTPError as e:
        return f"Error: API call failed - {e.response.text}"
    except KeyError:
        return "Error: Invalid API response format"
    except Exception as e:
        return f"Error: Unexpected issue - {str(e)}"

def chatbot_query(api, data):
    """
    Processes user input to provide app usage guidance or generate search query examples using the DeepSeek API.
    
    Args:
        data (str): JSON string containing 'message' (user input), and optionally 'client_type', 'occupation', 'keywords', or 'location'.
    
    Returns:
        dict: Response with status and message.
    """
    access_check = api.check_access_restriction()
    if access_check['status'] != 'success':
        return access_check
    try:
        # Parse input data
        request = json.loads(data)
        user_input = request.get("message", "").strip()
        client_type = request.get("client_type", "B2B")  # Default to B2B
        occupation = request.get("occupation", "").strip()
        keywords = request.get("keywords", "").strip()
        location = request.get("location", "").strip()

        if not user_input:
            return {
                "status": "error",
                "message": "Please provide a question or request!"
            }

        # Keywords to detect user intent
        app_usage_keywords = ["how", "use", "feature", "search", "section", "option", "menu", "work", "tutorial", "guide"]
        query_gen_keywords = ["example", "query", "search idea", "lead", "occupation", "need", "want", "type"]
        instagram_keywords = ["instagram", "post", "ad", "comment", "like"]
        consent_keywords = ["consent", "approval", "letter", "email", "username"]
        dashboard_keywords = ["statistic", "dashboard", "data", "success", "rate"]

        # Determine intent based on input
        if any(kw in user_input.lower() for kw in instagram_keywords):
            prompt = (
                f"The user asked: '{user_input}'. Provide a step-by-step guide on using the Instagram Post/Ad Interaction Lead Search "
                f"feature in SmartSearch Leads. If keywords ('{keywords}') or occupation ('{occupation}') are provided, tailor the example. "
                f"Format with an introductory sentence, followed by a numbered list of steps (e.g., '1. Go to the section\n2. Enter your data'). "
                f"Include an example query or scenario (e.g., finding leads commenting on realtor ads)."
            )
        elif any(kw in user_input.lower() for kw in consent_keywords):
            prompt = (
                f"The user asked: '{user_input}'. Explain how to use the Consent Management feature in SmartSearch Leads to send consent requests "
                f"via Instagram or email. Format with an introductory sentence, followed by a numbered list of steps. Include an example (e.g., sending a consent letter to an Instagram user)."
            )
        elif any(kw in user_input.lower() for kw in dashboard_keywords):
            prompt = (
                f"The user asked: '{user_input}'. Describe how to use the Statistics Dashboard in SmartSearch Leads to view lead data and success rates. "
                f"Format with an introductory sentence, followed by a numbered list of steps. Include an example (e.g., checking granted consents)."
            )
        elif any(kw in user_input.lower() for kw in query_gen_keywords) or keywords or occupation:
            prompt = (
                f"The user asked: '{user_input}'. Generate 3-4 example search queries for the Intent Lead Search feature in SmartSearch Leads. "
                f"Tailor queries to the occupation ('{occupation}'), keywords ('{keywords}'), and location ('{location}') if provided, or infer them. "
                f"Format with an introductory sentence, followed by a newline-separated numbered list of queries (e.g., '1. query1\n2. query2'). "
                f"Ensure queries are specific for social platforms (e.g., Instagram, LinkedIn)."
            )
        elif any(kw in user_input.lower() for kw in app_usage_keywords):
            prompt = (
                f"The user asked: '{user_input}'. Provide a step-by-step explanation on how to use the relevant feature of the SmartSearch Leads app "
                f"(e.g., Local B2B Business Search or Intent Lead Search). Format with an introductory sentence, followed by a numbered list of steps. "
                f"Include a simple example if applicable."
            )
        else:
            prompt = (
                f"The user asked: '{user_input}'. Provide a helpful overview of the SmartSearch Leads app, focusing on its key features: "
                f"Instagram Post/Ad Interaction Lead Search, Local B2B Business Search, Intent Lead Search, Consent Management, and Statistics Dashboard. "
                f"Format with an introductory sentence, followed by a numbered list of features with bullet points for sub-details. "
                f"Suggest asking a specific question."
            )

        response = call_deepseek_api(prompt)
        return {
            "status": "success",
            "message": response
        }

    except json.JSONDecodeError:
        return {
            "status": "error",
            "message": "Invalid input format. Please provide a valid JSON string."
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Unexpected error: {str(e)}"
        }