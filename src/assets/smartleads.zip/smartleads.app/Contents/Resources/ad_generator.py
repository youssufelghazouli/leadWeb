import os
import sys
import time
import shutil
import zipfile
import tempfile
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import tkinter as tk
from tkinter import messagebox
import requests
import json
from datetime import datetime
import sqlite3
from SecondAutomation import make_transparent, handle_recaptcha, define_timetoexecute  # Import shared functions

# OpenRouter API configuration
OPENROUTER_API_KEY = "sk-a2f4a026e0094d85b9cdac44ff050b80"
OPENROUTER_API_URL = "https://api.deepseek.com/v1/chat/completions"
HEADERS = {
    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
    "Content-Type": "application/json"
}

# Proxy credentials and settings
PROXY_HOST = "isp.oxylabs.io"
PROXY_PORT = 8001
PROXY_USER = "smartleads_ffSW0"
PROXY_PASS = "SmartleadsProduct123_"


def call_openrouter_api(prompt, previous_tables=None):
    messages = [
        {"role": "system", "content": "You are a helpful assistant that organizes data into tables in a markdown format (e.g., | Name | Username |)."},
        {"role": "user", "content": prompt[:10000]}
    ]
    if previous_tables:
        messages.append({"role": "user", "content": f"Previous tables:\n{previous_tables[:10000]}"})
    
    payload = {
        "model": "deepseek-chat",
        "messages": messages,
        "max_tokens": 4096,
        "temperature": 0.7
    }
    
    try:
        response = requests.post(OPENROUTER_API_URL, headers=HEADERS, json=payload)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except requests.exceptions.HTTPError as e:
        print(f"OpenRouter API call failed: {e}")
        print(f"Response: {e.response.text}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None

def save_to_database(api, table_data):
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS instagram_leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            username TEXT,
            consent_status TEXT DEFAULT 'Pending'
        )
    ''')
    
    rows = table_data.strip().split("\n")[2:]  # Skip header and separator
    for row in rows:
        if row.strip():
            cells = [cell.strip() for cell in row.split("|")[1:-1]]
            if len(cells) == 2 and any(cells):  # Ensure at least one field is non-empty
                cursor.execute('''
                    INSERT INTO instagram_leads (name, username)
                    VALUES (?, ?)
                ''', cells)
    
    conn.commit()
    conn.close()
    print("Instagram leads saved to database successfully.")

def login_to_instagram(driver):
    make_transparent()
    
    def get_resource_path(filename):
        """Resolve resource path for PyInstaller."""
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_path, filename)

    def get_db_path(db_name):
        """Resolve database path for PyInstaller, macOS-compatible."""
        if getattr(sys, 'frozen', False):
            app_data_dir = os.path.expanduser('~/Library/Application Support/SmartLeads')
            try:
                os.makedirs(app_data_dir, exist_ok=True)
            except PermissionError as e:
                print(f"Failed to create directory {app_data_dir}: {e}")
                raise
            writable_db_path = os.path.join(app_data_dir, db_name)
            bundled_db_path = get_resource_path(db_name)
            if not os.path.exists(writable_db_path) and os.path.exists(bundled_db_path):
                try:
                    shutil.copy(bundled_db_path, writable_db_path)
                except Exception as e:
                    print(f"Failed to copy database to {writable_db_path}: {e}")
                    raise
            return writable_db_path
        else:
            return os.path.join(os.path.dirname(os.path.abspath(__file__)), db_name)

    def connect_to_db(db_name):
        """Connect to the database."""
        db_path = get_db_path(db_name)
        try:
            conn = sqlite3.connect(db_path, check_same_thread=False)
            print(f"Connected to {db_name} at {db_path}")
            return conn
        except Exception as e:
            print(f"Error connecting to {db_name}: {e}")
            raise

    def init_cookies_table():
        """Initialize the instagram_cookies table if it doesn't exist."""
        conn = connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS instagram_cookies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                cookies TEXT,
                created_at TEXT
            )
        ''')
        conn.commit()
        conn.close()

    def load_cookies():
        """Load cookies from the database."""
        try:
            conn = connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute('SELECT cookies FROM instagram_cookies ORDER BY created_at DESC LIMIT 1')
            result = cursor.fetchone()
            conn.close()
            if result:
                cookies = json.loads(result[0])
                for cookie in cookies:
                    try:
                        driver.add_cookie(cookie)
                    except Exception as e:
                        print(f"Failed to add cookie {cookie.get('name')}: {e}")
                print("Loaded cookies from database.")
                return True
            return False
        except Exception as e:
            print(f"Failed to load cookies: {e}")
            return False

    def save_cookies():
        """Save current cookies to the database."""
        try:
            cookies = driver.get_cookies()
            conn = connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute('DELETE FROM instagram_cookies')  # Clear old cookies
            cursor.execute(
                'INSERT INTO instagram_cookies (cookies, created_at) VALUES (?, ?)',
                (json.dumps(cookies), datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            )
            conn.commit()
            conn.close()
            print("Saved cookies to database.")
        except Exception as e:
            print(f"Failed to save cookies: {e}")

    def attempt_login():
        """Perform login with username and password."""
        try:
            username_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.NAME, "username"))
            )
            password_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.NAME, "password"))
            )
            username_field.clear()
            username_field.send_keys("SmartSalesFinderAI")
            password_field.clear()
            password_field.send_keys("thesmartleadsproject123!")
            login_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//button[@type='submit']"))
            )
            login_button.click()
            time.sleep(5)
            return True
        except Exception as e:
            print(f"Error during login attempt: {e}")
            return False

    # Initialize cookies table
    init_cookies_table()

    # Navigate to Instagram
    driver.get("https://www.instagram.com/")
    time.sleep(3)

    # Try loading cookies first
    if load_cookies():
        driver.refresh()
        time.sleep(3)
        try:
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.NAME, "username"))
            )
            print("Cookies failed, login page still present. Proceeding with login.")
        except TimeoutException:
            print("Cookies worked, logged in successfully.")
            return True

    # If cookies failed or don't exist, perform login
    max_attempts = 4
    attempt_count = 1

    if not attempt_login():
        raise Exception("Initial login failed")

    while attempt_count <= max_attempts:
        try:
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.NAME, "username"))
            )
            WebDriverWait(driver, 5).until(
                EC.presence_of_element_located((By.NAME, "password"))
            )
            print("Detected another login page, attempting to log in again...")
            attempt_count += 1
            if not attempt_login():
                raise Exception(f"Login attempt {attempt_count} failed")
        except TimeoutException:
            print("Logged into Instagram successfully.")
            save_cookies()
            return True

    if attempt_count > max_attempts:
        return False
    
def run(api, query, city, progress_callback=None, start_page=1, total_pages=None):
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--start-maximized")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_argument("--incognito")  # Use incognito mode to prevent saving credentials
    options.add_argument("--disable-save-password-bubble")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    
    # Selenium Wire proxy config
    seleniumwire_options = {
        'proxy': {
            'http': f'http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'https': f'https://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'no_proxy': 'localhost,127.0.0.1'
        }
    }

    driver = webdriver.Chrome(options=options, seleniumwire_options=seleniumwire_options)

    token_consume = False
    try:
        if progress_callback:
            progress_callback({"progress": 5, "links_processed": 0, "total_links": 10})

        token_consume = login_to_instagram(driver)

        if not token_consume:
            return token_consume
        
        driver.execute_script("window.open('');")
        make_transparent()
        driver.switch_to.window(driver.window_handles[1])
        make_transparent()
        driver.get("https://www.google.com/")
        search_box = driver.find_element(By.NAME, "q")
        
        search_query = f"{query} {city} instagram posts"
        search_box.send_keys(search_query)
        search_box.send_keys(Keys.RETURN)

        if progress_callback:
            progress_callback({"progress": 10, "links_processed": 0, "total_links": 10})

        handle_recaptcha(driver, api)
        time.sleep(2)

        define_timetoexecute(driver, api)
        actions = ActionChains(driver)

        all_tables = []

        if start_page > 1:
            try:
                page_xpath = f'//a[@aria-label="Page {start_page}"]'
                pagination_link = driver.find_element(By.XPATH, page_xpath)
                pagination_link.click()
                time.sleep(6)
                handle_recaptcha(driver, api)
            except NoSuchElementException:
                print(f"Page {start_page} not found, ending search.")
                if progress_callback:
                    progress_callback({"progress": 100, "links_processed": 0, "total_links": 10})
                return token_consume

        if not total_pages:
            try:
                last_page_link = driver.find_elements(By.XPATH, '//a[@aria-label][contains(@aria-label, "Page ")]')[-1]
                total_pages = int(last_page_link.get_attribute("aria-label").split("Page ")[1]) * 2.6
            except:
                total_pages = 26

        try:
            search_links = driver.find_elements(By.XPATH, '//a[@href and not(@class="ab_button")]')
            link_urls = [link.get_attribute('href') for link in search_links if link.get_attribute('href') and 'instagram.com' in link.get_attribute('href')]
            processed_urls = set()
            links_processed = 0

            for link_url in link_urls[:10]:
                if link_url not in processed_urls:
                    driver.get(link_url)
                    time.sleep(10)
                    try:
                        firstclick = WebDriverWait(driver, 15).until(
                            EC.element_to_be_clickable((By.CLASS_NAME, "_aagw"))
                        )
                        firstclick.click()
                        print("Clicked first post")
                        time.sleep(2)  # Small delay for stability

                        # Wait for post overlay to load
                        WebDriverWait(driver, 15).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, "div[role='dialog']"))
                        )

                        # Find all elements matching the likes button selector and click the last one
                        likes_buttons = WebDriverWait(driver, 15).until(
                            EC.presence_of_all_elements_located((
                                By.CSS_SELECTOR, ".x193iq5w.xeuugli.x1fj9vlw.x13faqbe.x1vvkbs.xt0psk2.x1i0vuye.xvs91rp.x1s688f.x5n08af.x10wh9bi.x1wdrske.x8viiok.x18hxmgj"
                            ))
                        )
                        if not likes_buttons:
                            raise NoSuchElementException("No likes buttons found")
                        
                        # Click the last button (typically "others" or "# of likes")
                        secondclick = likes_buttons[-1]
                        secondclick.click()
                        print("Clicked likes button")
                        time.sleep(2)  # Small delay after click

                        # Wait for likes container
                        likes_container = WebDriverWait(driver, 10).until(
                            EC.presence_of_element_located((
                                By.XPATH, "//div[@role='dialog']//div[contains(@style, 'max-height: 356px')]/div[contains(@style, 'overflow: hidden auto')]"
                            ))
                        )

                        all_scraped_content = []
                        scroll_increment = 356
                        total_height = driver.execute_script("return arguments[0].scrollHeight", likes_container)
                        current_position = 0

                        while current_position < total_height:
                            current_content = driver.execute_script("return arguments[0].innerText", likes_container)
                            all_scraped_content.append(current_content)
                            driver.execute_script(f"arguments[0].scrollTop = {current_position + scroll_increment}", likes_container)
                            time.sleep(1)
                            current_position += scroll_increment
                            total_height = driver.execute_script("return arguments[0].scrollHeight", likes_container)

                        scraped_content = "\n".join(set(all_scraped_content))
                        prompt = (
                            f"Organize this input into a markdown table with columns: | Name | Username |. "
                            f"Extract only names and Instagram usernames from the content. "
                            f"Just fill the information you have from this input:\n\n{scraped_content}"
                        )
                        table_response = call_openrouter_api(prompt)
                        if table_response:
                            all_tables.append(table_response)
                            print(f"Processed content from {link_url} into table.")
                        
                        processed_urls.add(link_url)
                        links_processed += 1
                        driver.back()
                        time.sleep(1)
                        handle_recaptcha(driver, api)
                    except Exception as e:
                        print(f"Error processing link {link_url}: {e}")
                        driver.back()
                        time.sleep(1)

                    if progress_callback:
                        progress = min(10 + (links_processed * 80 / 10), 90)
                        progress_callback({"progress": progress, "links_processed": links_processed, "total_links": 10})

        except Exception as e:
            print(f"Unexpected error on Page {start_page}: {e}")

        if all_tables:
            if progress_callback:
                progress_callback({"progress": 95, "links_processed": links_processed, "total_links": 10})
            final_prompt = (
                "Combine all these tables into one big markdown table with columns: | Name | Username |. Include all information in the table from the past tables but dont start the table with the Name, Username Header, just start immediately from the first row of data as this is very important."
                "Ensure no information is lost from the tables provided. "
                "Exclude rows that seem like a scam or bot account which might have xoxo or heart or love or similar in the name, but keep as much of the data as possible. "
                "Exclude any duplicate rows. "
                "Here are the tables:\n\n" + "\n\n".join(all_tables)
            )
            final_table = call_openrouter_api(final_prompt)
            if final_table:
                print("Processed table for current page successfully.")
                save_to_database(api, final_table)
            else:
                print("Failed to process table for current page.")
        else:
            print("No tables generated from scraped data for this page.")

        if progress_callback:
            progress_callback({"progress": 100, "links_processed": links_processed, "total_links": 10})
        print(f"Completed processing Page {start_page} with {links_processed} links.")

    finally:
        try:
            driver.quit()
            print("Chrome driver closed.")
        except Exception as e:
            print(f"Error closing Chrome driver: {e}")
        
        time.sleep(2)
        return token_consume
