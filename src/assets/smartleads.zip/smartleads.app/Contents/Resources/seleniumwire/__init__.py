# -*- coding: utf-8 -*-

"""Top-level package for Selenium Wire."""

__author__ = """Will Keeling"""
__version__ = '5.1.0'
