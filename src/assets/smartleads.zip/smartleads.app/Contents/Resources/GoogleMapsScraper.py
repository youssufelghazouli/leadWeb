from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException, WebDriverException
import time
import re
import os
import sqlite3
from SecondAutomation import make_transparent, handle_recaptcha, define_timetoexecute  # Import shared functions


def run(api, profession="realtor", progress_callback=None):
    # Setup Selenium
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--start-maximized")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    driver = webdriver.Chrome(options=options)

    all_data = []  # Collect data even if interrupted
    processed_links = set()
    total_links = 0

    make_transparent()
    try:
        # Navigate to Google Maps
        driver.get("https://www.google.com/maps")
        
        # Initial search for the profession
        try:
            search_box = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, "searchboxinput"))
            )
            search_box.clear()
            search_box.send_keys(profession)
            search_box.send_keys(Keys.RETURN)

        except Exception as e:
            print(f"Error with initial search: {e}")
            save_to_database(api, all_data)  # Save whatever we have
            driver.quit()
            return

        # Wait 5 seconds for results to load
        time.sleep(5)

        # Pre-scraping: Scroll all the way down until no new links for two 10-second waits
        print("Pre-scraping: Scrolling to load all results...")
        consecutive_no_new_links = 0
        last_count = 0

        while consecutive_no_new_links < 2:
            try:
                scroll_pane = driver.find_element(By.XPATH, "//div[contains(@class, 'm6QErb')]//div[@role='feed']")
                driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", scroll_pane)
                time.sleep(2)

                business_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                current_count = len(business_links)
                print(f"Current business links count: {current_count}")

                if current_count <= last_count:
                    print("No new links found, waiting 10 seconds...")
                    time.sleep(10)
                    business_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                    if len(business_links) <= last_count:
                        consecutive_no_new_links += 1
                        print(f"Consecutive no new links: {consecutive_no_new_links}")
                    else:
                        consecutive_no_new_links = 0
                        last_count = len(business_links)
                else:
                    consecutive_no_new_links = 0
                    last_count = current_count
                    total_links = current_count

            except Exception as e:
                print(f"Error during pre-scraping scroll: {e}")
                break
        
        if progress_callback:
            progress_callback({"progress": 5, "links_processed": 0, "total_links": total_links or 10})

        # Scroll back to the top
        print("Scrolling back to the top to start scraping...")
        driver.execute_script("arguments[0].scrollTop = 0", scroll_pane)
        time.sleep(2)

        links_processed = 0
        # Collect all business links and start scraping
        while True:
            try:
                business_links = WebDriverWait(driver, 10).until(
                    EC.presence_of_all_elements_located((By.CLASS_NAME, "hfpxzc"))
                )
                print(f"Found {len(business_links)} business links in this batch")

                for i in range(len(business_links)):
                    business_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                    if i >= len(business_links):
                        break

                    link = business_links[i]
                    link_id = link.get_attribute("href")
                    if link_id in processed_links:
                        continue

                    try:
                        driver.execute_script("arguments[0].scrollIntoView({block: 'center'});", link)
                        time.sleep(1)
                        link.click()
                        time.sleep(4)

                        company_name = WebDriverWait(driver, 5).until(
                            EC.presence_of_element_located((By.CLASS_NAME, "DUwDvf.lfPIob"))
                        ).text.strip()

                        info_elements = WebDriverWait(driver, 5).until(
                            EC.presence_of_all_elements_located((By.CLASS_NAME, "Io6YTe.fontBodyMedium.kR99db.fdkmkc"))
                        )
                        content = "\n".join([elem.text for elem in info_elements if elem.text])

                        phone_pattern = r"\(\d{3}\)\s*\d{3}-\d{4}"
                        address_pattern = r"^(.*?)(?=\n|$)"
                        city_pattern = r"(Vancouver|Burnaby|Surrey|Victoria)"

                        entry = {
                            "Company": company_name,
                            "Address": re.search(address_pattern, content).group().title() if re.search(address_pattern, content) else "",
                            "Number": re.search(phone_pattern, content).group() if re.search(phone_pattern, content) else "",
                            "City": re.search(city_pattern, content, re.IGNORECASE).group().title() if re.search(city_pattern, content, re.IGNORECASE) else ""
                        }

                        if entry["Number"] and not entry["Number"].replace("(", "").replace(")", "").replace("-", "").startswith(("604", "778", "250")):
                            entry["Number"] = ""

                        all_data.append(entry)
                        processed_links.add(link_id)
                        links_processed += 1
                        print(f"Processed business {len(all_data)}: {entry['Company']}")

                        if progress_callback and total_links > 0:
                            progress = min(5 + (links_processed * 90 / total_links), 95)
                            progress_callback({"progress": progress, "links_processed": links_processed, "total_links": total_links})

                        driver.back()
                        time.sleep(2)

                    except Exception as e:
                        print(f"Error processing business {i + 1}: {e}")
                        driver.back()
                        time.sleep(2)

                try:
                    scroll_pane = driver.find_element(By.XPATH, "//div[contains(@class, 'm6QErb')]//div[@role='feed']")
                    driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", scroll_pane)
                    time.sleep(2)

                    new_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                    new_count = len(new_links)
                    old_count = len(business_links)

                    if new_count <= old_count:
                        print("No new links found, waiting 10 seconds to confirm...")
                        time.sleep(10)
                        new_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                        if len(new_links) <= old_count:
                            driver.execute_script("arguments[0].scrollTop = arguments[0].scrollHeight", scroll_pane)
                            time.sleep(2)
                            new_links = driver.find_elements(By.CLASS_NAME, "hfpxzc")
                            if len(new_links) <= old_count:
                                print("No more businesses to scrape, exiting...")
                                break
                    business_links = new_links
                    total_links = max(total_links, len(business_links))

                except Exception as e:
                    print(f"Error scrolling or no more results: {e}")
                    break

            except (NoSuchElementException, TimeoutException, WebDriverException) as e:
                print(f"Scraping interrupted or no more business links found: {e}")
                break  # Exit the loop if elements are not found or driver is interrupted

    except WebDriverException as e:
        print(f"Driver interrupted (e.g., browser closed): {e}")
        # Save whatever data we have before quitting

    finally:
        # Save collected data to database and clean up
        if all_data:
            save_to_database(api, all_data)
            print(f"Script completed. Saved {len(all_data)} entries to database.")
        else:
            print("No data collected to save.")
        try:
            driver.quit()
        except Exception as e:
            print(f"Error closing driver: {e}")

def save_to_database(api, data):
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS local_leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            company TEXT,
            address TEXT,
            number TEXT,
            city TEXT
        )
    ''')
    for entry in data:
        cursor.execute('''
            INSERT INTO local_leads (company, address, number, city)
            VALUES (?, ?, ?, ?)
        ''', (entry["Company"], entry["Address"], entry["Number"], entry["City"]))
    conn.commit()
    conn.close()