import stripe
import sqlite3
import json
from datetime import datetime, timedelta
import smtplib
from email.mime.text import MIMEText

# Initialize Stripe
stripe.api_key = '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'  # Replace with your Stripe secret key

DB_PATH = "leads.db"


class StripeTokenManager:
    def __init__(self):
        pass

    def send_confirmation_email(self, email, name, subject, body):
        GMAIL_USER = "smartleadsproduction@gmail.com"
        GMAIL_PASS = "fhrccajtlxlaegle"
        sender = GMAIL_USER
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = email

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(GMAIL_USER, GMAIL_PASS)
                server.sendmail(sender, [email], msg.as_string())
            return {"status": "success", "message": f"Confirmation email sent to {email}"}
        except Exception as e:
            return {"status": "error", "message": f"Failed to send confirmation email to {email}: {e}"}

    def purchase_tokens(self, user_id, stripe_token, quantity, amount):
        try:
            if quantity < 100000 or quantity > 1000000 or quantity % 100000 != 0:
                return {'status': 'error', 'message': 'Token quantity must be between 100,000 and 1,000,000 in increments of 100,000'}
            if amount != (quantity // 100000) * 75800:
                return {'status': 'error', 'message': 'Invalid amount for token quantity'}

            customers = stripe.Customer.list(email=user_id, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id
            name = customer.metadata.get("name", "User")

            # Get the fingerprint of the entered card
            card = stripe.Token.retrieve(stripe_token).card
            card_fingerprint = card.fingerprint
            if not card_fingerprint:
                return {"status": "error", "message": "Unable to retrieve card fingerprint!"}

            # Check the customer's existing payment methods
            payment_methods = stripe.PaymentMethod.list(customer=customer_id, type='card')
            matching_payment_method = None
            for pm in payment_methods.auto_paging_iter():
                if pm.card and pm.card.fingerprint and pm.card.fingerprint == card_fingerprint:
                    matching_payment_method = pm
                    break

            if not matching_payment_method:
                return {
                    "status": "error",
                    "message": "Please use the card associated with your account to purchase tokens. If you need to update your payment method, contact support."
                }

            # Create a temporary PaymentMethod from the stripe_token
            temp_payment_method = stripe.PaymentMethod.create(
                type='card',
                card={'token': stripe_token}
            )

            # Attach the temporary PaymentMethod to the customer for validation
            stripe.PaymentMethod.attach(temp_payment_method.id, customer=customer_id)

            # Create a SetupIntent to validate the PaymentMethod
            validation_setup_intent = stripe.SetupIntent.create(
                customer=customer_id,
                payment_method=temp_payment_method.id,
                confirm=True,
                usage='off_session',
                automatic_payment_methods={
                    'enabled': True,
                    'allow_redirects': 'never'
                }
            )

            # Check if the SetupIntent succeeded
            if validation_setup_intent.status != 'succeeded':
                stripe.PaymentMethod.detach(temp_payment_method.id)
                return {
                    "status": "error",
                    "message": f"Card validation failed: {validation_setup_intent.last_setup_error.message if validation_setup_intent.last_setup_error else 'Unknown error'}"
                }

            # Create a small PaymentIntent to force Radar rules to apply (50 cents, minimum charge)
            validation_payment_intent = stripe.PaymentIntent.create(
                amount=50,  # 50 cents, minimum charge in USD
                currency='usd',
                customer=customer_id,
                payment_method=temp_payment_method.id,
                off_session=True,
                confirm=True,
                description='Temporary validation charge for token purchase'
            )

            # Check if the PaymentIntent succeeded (this triggers Radar rules)
            if validation_payment_intent.status != 'succeeded':
                stripe.PaymentMethod.detach(temp_payment_method.id)
                return {
                    "status": "error",
                    "message": f"Card validation failed: {validation_payment_intent.last_payment_error.message if validation_payment_intent.last_payment_error else 'Unknown error'}"
                }

            # Cancel the PaymentIntent to avoid charging the user
            stripe.PaymentIntent.cancel(validation_payment_intent.id)

            # Detach the temporary PaymentMethod
            stripe.PaymentMethod.detach(temp_payment_method.id)

            # Check if the customer has a default payment method
            if not customer.invoice_settings.default_payment_method and not customer.default_source:
                return {
                    "status": "error",
                    "message": "No default payment method found for your account. Please contact support to update your payment details."
                }

            # Create a Payment Intent instead of a Charge
            payment_intent = stripe.PaymentIntent.create(
                amount=amount,
                currency='usd',
                customer=customer_id,
                payment_method=customer.invoice_settings.default_payment_method or customer.default_source,
                off_session=True,  # Allows charging without customer interaction
                confirm=True,  # Immediately confirm the Payment Intent
                description=f'Purchase of {quantity} tokens for {user_id}'
            )

            # Check if the Payment Intent succeeded
            if payment_intent.status != 'succeeded':
                return {
                    "status": "error",
                    "message": f"Payment failed: {payment_intent.status}. Please try again or contact support."
                }

            # Update token balance in customer metadata
            current_balance = int(customer.metadata.get("token_balance", 0))
            new_balance = current_balance + quantity

            stripe.Customer.modify(
                customer_id,
                metadata={
                    "token_balance": new_balance,
                    "subscription_status": customer.metadata.get("subscription_status", "none"),
                    "subscription_start": customer.metadata.get("subscription_start"),
                    "last_reset_date": customer.metadata.get("last_reset_date")
                }
            )

            # Send token purchase confirmation email
            subject = "SmartLeads Token Purchase Confirmation"
            body = (
                f"Hi {name},\n\n"
                f"Thank you for purchasing {quantity:,} tokens!\n\n"
                f"Purchase Details:\n"
                f"- Tokens Purchased: {quantity:,}\n"
                f"- New Token Balance: {new_balance:,}\n"
                f"- Amount Charged: ${(amount / 100):.2f} USD\n\n"
                f"Start using your tokens now!\n\n"
                f"Best,\nSmartLeads Team"
            )
            email_response = self.send_confirmation_email(user_id, name, subject, body)
            if email_response["status"] == "error":
                print(email_response["message"])  # Log error but don't fail

            return {"status": "success", "message": f"Successfully purchased {quantity:,} tokens!"}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Payment error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Unexpected error: {str(e)}"}
       
    def start_subscription(self, user_id, stripe_token):
        try:
            # Check if the user already has an active or trial subscription
            sub_status = self.check_subscription(user_id)
            if sub_status['status'] == 'success' and sub_status['has_active_or_trialing']:
                return {"status": "error", "message": "You already have an active or trial subscription! Please cancel your existing subscription before starting a new one."}

            # Check if email exists in Stripe (shouldn't happen since user_id should match)
            customers = stripe.Customer.list(email=user_id, limit=1)
            customer_id = None
            if customers.data:
                customer = customers.data[0]
                customer_id = customer.id
                name = customer.metadata.get("name", "User")
            else:
                return {"status": "error", "message": "User not found in Stripe!"}

            # Get the fingerprint of the entered card
            card = stripe.Token.retrieve(stripe_token).card
            card_fingerprint = card.fingerprint
            if not card_fingerprint:
                return {"status": "error", "message": "Unable to retrieve card fingerprint!"}

            # Check the customer's existing payment methods to ensure the card matches
            payment_methods = stripe.PaymentMethod.list(customer=customer_id, type='card')
            matching_payment_method = None
            for pm in payment_methods.auto_paging_iter():
                if pm.card and pm.card.fingerprint and pm.card.fingerprint == card_fingerprint:
                    matching_payment_method = pm
                    break

            if not matching_payment_method:
                return {
                    "status": "error",
                    "message": "Please use the card associated with your account to start a subscription. If you need to update your payment method, contact support."
                }

            # Create a temporary PaymentMethod from the stripe_token
            temp_payment_method = stripe.PaymentMethod.create(
                type='card',
                card={'token': stripe_token}
            )

            # Attach the temporary PaymentMethod to the customer for validation
            stripe.PaymentMethod.attach(temp_payment_method.id, customer=customer_id)

            # Create a SetupIntent to validate the PaymentMethod
            validation_setup_intent = stripe.SetupIntent.create(
                customer=customer_id,
                payment_method=temp_payment_method.id,
                confirm=True,
                usage='off_session',
                automatic_payment_methods={
                    'enabled': True,
                    'allow_redirects': 'never'
                }
            )

            # Check if the SetupIntent succeeded
            if validation_setup_intent.status != 'succeeded':
                stripe.PaymentMethod.detach(temp_payment_method.id)
                return {
                    "status": "error",
                    "message": f"Card validation failed: {validation_setup_intent.last_setup_error.message if validation_setup_intent.last_setup_error else 'Unknown error'}"
                }

            # Create a small PaymentIntent to force Radar rules to apply (50 cents, minimum charge)
            validation_payment_intent = stripe.PaymentIntent.create(
                amount=50,  # 50 cents, minimum charge in USD
                currency='usd',
                customer=customer_id,
                payment_method=temp_payment_method.id,
                off_session=True,
                confirm=True,
                description='Temporary validation charge for subscription start'
            )

            # Check if the PaymentIntent succeeded (this triggers Radar rules)
            if validation_payment_intent.status != 'succeeded':
                stripe.PaymentMethod.detach(temp_payment_method.id)
                return {
                    "status": "error",
                    "message": f"Card validation failed: {validation_payment_intent.last_payment_error.message if validation_payment_intent.last_payment_error else 'Unknown error'}"
                }

            # Cancel the PaymentIntent to avoid charging the user
            stripe.PaymentIntent.cancel(validation_payment_intent.id)

            # Detach the temporary PaymentMethod
            stripe.PaymentMethod.detach(temp_payment_method.id)

            # If validation succeeds, proceed with subscription creation using the existing default_payment_method
            today = datetime.now().date().strftime("%Y-%m-%d")
            subscription = stripe.Subscription.create(
                customer=customer_id,
                items=[{'price': 'price_1RJl8CB310pZ8hVHj1ULqclV'}]
            )

            # Get the current token balance and add 100,000 tokens
            current_token_balance = int(customer.metadata.get("token_balance", "0"))
            new_token_balance = current_token_balance + 100000

            # Update customer metadata with the new token balance
            stripe.Customer.modify(
                customer_id,
                metadata={
                    "token_balance": new_token_balance,
                    "subscription_status": "active",
                    "subscription_start": today,
                    "last_reset_date": today,
                    "name": name  # Preserve name if already set
                }
            )

            # Send subscription confirmation email
            current_period_end = datetime.fromtimestamp(subscription.current_period_end).strftime('%Y-%m-%d')
            subject = "SmartLeads Subscription Confirmation"
            body = (
                f"Hi {name},\n\n"
                f"Your SmartLeads subscription is now active!\n\n"
                f"Subscription Details:\n"
                f"- Current Token Balance: {new_token_balance}\n"
                f"- Billing Period End: {current_period_end}\n"
                f"- Note: This is a 12-month minimum commitment.\n\n"
                f"Enjoy full access to SmartLeads features!\n\n"
                f"Best,\nSmartLeads Team"
            )
            email_response = self.send_confirmation_email(user_id, name, subject, body)
            if email_response["status"] == "error":
                print(email_response["message"])  # Log error but don't fail

            return {"status": "success", "message": f"Subscription started! You now have {new_token_balance} tokens. Note: This is a 12-month minimum commitment."}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Unexpected error: {str(e)}"}
    
    def cancel_subscription(self, user_email):
        try:
            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id
            name = customer.metadata.get("name", "User")

            subscriptions = stripe.Subscription.list(customer=customer_id, status='all', limit=1)
            if not subscriptions.data:
                return {"status": "error", "message": "No subscription found for user!"}
            subscription = subscriptions.data[0]
            subscription_id = subscription.id
            subscription_status = customer.metadata.get("subscription_status", "none")
            subscription_start = customer.metadata.get("subscription_start")
            current_balance = int(customer.metadata.get("token_balance", 0))

            if subscription_status not in ['trial', 'active']:
                return {"status": "error", "message": "No active or trial subscription to cancel!"}

            if subscription_status == 'active':
                if not subscription_start:
                    return {"status": "error", "message": "Subscription start date not found!"}
                sub_start = datetime.strptime(subscription_start, "%Y-%m-%d").date()
                today = datetime.now().date()
                if today > sub_start + timedelta(days=14):
                    return {"status": "error", "message": "Cancellation period (14 days) has expired!"}
            
            # Update customer metadata to reflect cancellation
            stripe.Customer.modify(
                customer_id,
                metadata={
                    "token_balance": current_balance,
                    "subscription_status": "canceled",
                    "subscription_start": subscription_start,
                    "last_reset_date": customer.metadata.get("last_reset_date")
                }
            )
            stripe.Subscription.delete(subscription_id, prorate=False)

            # Send cancellation confirmation email
            subject = "SmartLeads Subscription Cancellation Confirmation"
            body = (
                f"Hi {name},\n\n"
                f"Your SmartLeads subscription has been canceled.\n\n"
                f"Details:\n"
                f"- No charges were incurred.\n"
                f"- Existing Tokens: {current_balance:,} (preserved)\n"
                f"- No further tokens will be granted.\n\n"
                f"If you have any questions, feel free to reach out.\n\n"
                f"Best,\nSmartLeads Team"
            )
            email_response = self.send_confirmation_email(user_email, name, subject, body)
            if email_response["status"] == "error":
                print(email_response["message"])  # Log error but don't fail

            return {"status": "success", "message": "Subscription canceled. No charges incurred, existing tokens preserved, and no further tokens will be granted."}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Cancellation error: {str(e)}"}
        
    def check_subscription(self, user_id):
        try:
            customers = stripe.Customer.list(email=user_id, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id

            # Get the initial subscription_status from metadata to determine if a new subscription is allowed
            initial_subscription_status = customer.metadata.get("subscription_status", "none")
            has_active_or_trialing = initial_subscription_status in ['active', 'trialing', 'trial']

            # Existing logic for syncing metadata with Stripe subscription status
            subscriptions = stripe.Subscription.list(customer=customer_id, status='all', limit=1)
            if not subscriptions.data:
                return {"status": "error", "message": "No subscription found for user!"}
            subscription = subscriptions.data[0]
            stripe_status = subscription.status

            subscription_status = customer.metadata.get("subscription_status", "none")
            current_balance = int(customer.metadata.get("token_balance", 0))

            # If Stripe status is 'trialing', update customer metadata to 'trial'
            if stripe_status == 'trialing' and subscription_status != 'trial':
                subscription_status = 'trial'
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": current_balance,
                        "subscription_status": "trial",
                        "subscription_start": customer.metadata.get("subscription_start"),
                        "last_reset_date": customer.metadata.get("last_reset_date")
                    }
                )

            # If customer metadata says 'trial' but Stripe status is 'active', update to 'active' and grant tokens
            elif subscription_status == 'trial' and stripe_status == 'active':
                new_balance = current_balance + 100000
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": new_balance,
                        "subscription_status": "active",
                        "subscription_start": customer.metadata.get("subscription_start"),
                        "last_reset_date": customer.metadata.get("last_reset_date")
                    }
                )
                subscription_status = 'active'

            # If Stripe status is 'canceled', 'past_due', or 'unpaid', update customer metadata
            elif stripe_status in ['canceled', 'past_due', 'unpaid']:
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": current_balance,
                        "subscription_status": stripe_status,
                        "subscription_start": customer.metadata.get("subscription_start"),
                        "last_reset_date": customer.metadata.get("last_reset_date")
                    }
                )
                subscription_status = stripe_status

            return {
                "status": "success",
                "subscription_status": subscription_status,
                "has_active_or_trialing": has_active_or_trialing
            }
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Check subscription error: {str(e)}"}
        
    def check_tokens(self, user_id):
        try:
            customers = stripe.Customer.list(email=user_id, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]

            balance = int(customer.metadata.get("token_balance", 0))
            subscription_status = customer.metadata.get("subscription_status", "none")
            return {"status": "success", "balance": balance, "subscription_status": subscription_status}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Check tokens error: {str(e)}"}

    def consume_token(self, user_id):
        try:
            customers = stripe.Customer.list(email=user_id, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id

            token_balance = int(customer.metadata.get("token_balance", 0))
            search_cost = 2000

            subscriptions = stripe.Subscription.list(customer=customer_id, status='all', limit=1)
            if not subscriptions.data:
                if token_balance < search_cost:
                    return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {token_balance:,} available."}
                new_balance = token_balance - search_cost
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": new_balance,
                    }
                )
                return {"status": "success", "message": "Tokens consumed", "balance": new_balance}

            subscription = subscriptions.data[0]
            subscription_status = subscription.status

            if subscription_status == 'canceled':
                if token_balance < search_cost:
                    return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {token_balance:,} available."}
                new_balance = token_balance - search_cost
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": new_balance,
                    }
                )
                return {"status": "success", "message": "Tokens consumed", "balance": new_balance}

            elif subscription_status == 'trialing':
                app_subscription_status = customer.metadata.get("subscription_status", "none")
                if app_subscription_status == 'trial' and subscription.status != 'trialing':
                    new_balance = token_balance + 100000
                    stripe.Customer.modify(
                        customer_id,
                        metadata={
                            "token_balance": new_balance,
                            "subscription_status": "active",
                        }
                    )
                    return {"status": "success", "message": "Trial ended, subscription activated with 100,000 tokens", "balance": new_balance}
                if token_balance < search_cost:
                    return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {token_balance:,} available."}
                new_balance = token_balance - search_cost
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": new_balance,
                        "subscription_status": app_subscription_status,
                    }
                )
                return {"status": "success", "message": "Tokens consumed", "balance": new_balance}

            elif subscription_status == 'active':
                app_subscription_status = customer.metadata.get("subscription_status", "none")
                if app_subscription_status != 'active':
                    new_balance = token_balance + 100000
                    stripe.Customer.modify(
                        customer_id,
                        metadata={
                            "token_balance": new_balance,
                            "subscription_status": "active",
                        }
                    )
                    return {"status": "success", "message": "New subscription activated with 100,000 tokens", "balance": new_balance}
                if token_balance < search_cost:
                    return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {token_balance:,} available."}
                new_balance = token_balance - search_cost
                stripe.Customer.modify(
                    customer_id,
                    metadata={
                        "token_balance": new_balance,
                        "subscription_status": "active",
                    }
                )
                return {"status": "success", "message": "Tokens consumed", "balance": new_balance}

            else:
                return {"status": "error", "message": f"Subscription status '{subscription_status}' does not allow token usage."}

        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Consume token error: {str(e)}"}