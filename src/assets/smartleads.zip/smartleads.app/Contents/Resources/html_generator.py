def generate_html(raw_content, filepath):
    """
    Generate an HTML file with a styled table from raw text content.

    Args:
        raw_content (str): Raw text content of the table (clipboard data).
        filepath (str): Path to save the HTML file.
    """
    # Parse raw content into rows and columns
    rows = raw_content.strip().split("\n")
    table_data = [row.split("|")[1:-1] for row in rows if "|" in row]  # Extract content between pipes

    # Start generating the HTML file
    with open(filepath, "w", encoding="utf-8") as file:
        file.write("<!DOCTYPE html>\n")
        file.write("<html lang='en'>\n")
        file.write("<head>\n")
        file.write("<meta charset='UTF-8'>\n")
        file.write("<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n")
        file.write("<title>Leads Table</title>\n")
        file.write("<style>\n")
        file.write("body { font-family: Arial, sans-serif; margin: 20px; background-color: #f9f9f9; color: #333; }\n")
        file.write("table { border-collapse: collapse; width: 100%; margin: 20px 0; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }\n")
        file.write("th, td { border: 1px solid #ddd; padding: 12px; text-align: left; }\n")
        file.write("th { background-color: #f4f4f4; font-weight: bold; }\n")
        file.write("tr:nth-child(even) { background-color: #f9f9f9; }\n")
        file.write("tr:hover { background-color: #f1f1f1; }\n")
        file.write("</style>\n")
        file.write("</head>\n")
        file.write("<body>\n")
        file.write("<h1>Leads Table</h1>\n")
        file.write("<table>\n")

        # Add table headers (first row)
        if table_data:
            file.write("<thead>\n<tr>\n")
            for header in table_data[0]:
                file.write(f"<th>{header.strip()}</th>\n")
            file.write("</tr>\n</thead>\n")

            # Add table rows
            file.write("<tbody>\n")
            for row in table_data[1:]:
                file.write("<tr>\n")
                for cell in row:
                    file.write(f"<td>{cell.strip()}</td>\n")
                file.write("</tr>\n")
            file.write("</tbody>\n")

        file.write("</table>\n")
        file.write("</body>\n")
        file.write("</html>\n")

    print(f"HTML table saved to {filepath} successfully.")
