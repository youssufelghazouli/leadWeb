import os
import sys
import time
import shutil
from selenium import webdriver
from AppKit import NSApplication
import threading
import queue
from PyObjCTools import AppHelper
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.remote.webdriver import WebDriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import ctypes
import pygetwindow as gw
import tkinter as tk
from tkinter import messagebox, ttk
from PIL import Image, ImageTk
from datetime import datetime
import requests
import sqlite3
import subprocess

# OpenRouter API configuration
OPENROUTER_API_KEY = "sk-a2f4a026e0094d85b9cdac44ff050b80"
OPENROUTER_API_URL = "https://api.deepseek.com/v1/chat/completions"
HEADERS = {
    "Authorization": f"Bearer {OPENROUTER_API_KEY}",
    "Content-Type": "application/json"
}

def create_custom_messagebox(title, message, api):
    def show_messagebox():
        try:
            # Escape quotes and newlines for AppleScript
            title_escaped = title.replace('"', '\\"').replace('\n', ' ')
            message_escaped = message.replace('"', '\\"').replace('\n', ' ')
            
            # Construct AppleScript to display a native macOS dialog
            script = f'display dialog "{message_escaped}" with title "{title_escaped}" buttons {{"OK"}} default button "OK"'
            
            # Run osascript with a timeout
            subprocess.run(
                ['osascript', '-e', script],
                capture_output=True,
                text=True,
                timeout=10.0,
                check=True
            )
            
            # Signal completion
            q.put(True)
        except (subprocess.TimeoutExpired, subprocess.SubprocessError, Exception):
            q.put(False)

    # Initialize queue for thread communication
    q = queue.Queue()
    
    # Check if running on the main thread
    if threading.current_thread() is threading.main_thread():
        show_messagebox()
    else:
        # Run show_messagebox on the main thread using PyObjC
        if NSApplication.sharedApplication() is None:
            NSApplication.sharedApplication()
        AppHelper.callAfter(show_messagebox)
        
        try:
            q.get(timeout=15.0)  # Wait for dialog completion
        except queue.Empty:
            pass


def define_timetoexecute(driver, api):
    try:
        xpath = f'//a[@aria-label="Page 10"]'
        link = driver.find_element(By.XPATH, xpath)
        message = "Large Amount of Data, Generation in 10 minutes"
    except Exception:
        message = "Minimal Amount of Data, Generation in 5 minutes"

    create_custom_messagebox("Execution Time", f"{message}\nPress OK to start search.", api)

def make_transparent():
    """ Hides all Google Chrome windows (simulating full transparency) """
    subprocess.run(["osascript", "-e", 'tell application "Google Chrome" to set visible of every window to false'])


def make_apparent():
    """ Makes all Google Chrome windows visible again """
    subprocess.run(["osascript", "-e", 'tell application "Google Chrome" to set visible of every window to true'])


def handle_recaptcha(driver, api):
    try:
        WebDriverWait(driver, 5).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, "iframe[title='reCAPTCHA']"))
        )
        driver.switch_to.frame(driver.find_element(By.CSS_SELECTOR, "iframe[title='reCAPTCHA']"))
        checkbox = WebDriverWait(driver, 5).until(
            EC.element_to_be_clickable((By.CLASS_NAME, "recaptcha-checkbox-border"))
        )
        checkbox.click()

        create_custom_messagebox("reCAPTCHA Puzzle", "Press OK to solve reCAPTCHA puzzle and continue searching. MUST WAIT FOR PAGE TO DISAPPEAR!", api)

        make_apparent()
        time.sleep(20)
        make_transparent()
        driver.switch_to.default_content()
        time.sleep(5)
    except (TimeoutException, NoSuchElementException):
        print("reCAPTCHA did not appear or could not be clicked.")

def call_openrouter_api(prompt, previous_tables=None):
    messages = [
        {"role": "system", "content": "You are a helpful assistant that organizes data into tables in a markdown format (e.g., | Name | Email | ... |)."},
        {"role": "user", "content": prompt[:10000]}
    ]
    if previous_tables:
        messages.append({"role": "user", "content": f"Previous tables:\n{previous_tables[:10000]}"})
    
    payload = {
        "model": "deepseek-chat",
        "messages": messages,
        "max_tokens": 4096,
        "temperature": 0.7
    }
    
    try:
        response = requests.post(OPENROUTER_API_URL, headers=HEADERS, json=payload)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except requests.exceptions.HTTPError as e:
        print(f"OpenRouter API call failed: {e}")
        print(f"Response: {e.response.text}")
        return None
    except Exception as e:
        print(f"Unexpected error: {e}")
        return None


def save_to_database(api, table_data):
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()
    
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS leads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            email TEXT,
            company TEXT,
            address TEXT,
            number TEXT,
            city TEXT,
            consent_status TEXT DEFAULT 'Pending'
        )
    ''')
    
    rows = table_data.strip().split("\n")[2:]
    for row in rows:
        if row.strip():
            cells = [cell.strip() for cell in row.split("|")[1:-1]]
            if len(cells) == 6:
                cursor.execute('''
                    INSERT INTO leads (name, email, company, address, number, city)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', cells)
    
    conn.commit()
    conn.close()
    print("Leads saved to database successfully.")

def run(api, site, query, city, profession, phonecode, start_date, progress_callback=None):
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--start-maximized")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_experimental_option("excludeSwitches", ["enable-automation"])
    driver = webdriver.Chrome(options=options)
    
    try:
        if progress_callback:
            progress_callback({"progress": 5, "current_page": 0, "total_pages": "unknown"})

        make_transparent()
        
        driver.get("https://www.google.com/")
        search_box = driver.find_element(By.NAME, "q")

        if not city:
            city = "(\"Vancouver\" OR \"vancouver\" OR \"Burnaby\" OR \"burnaby\" OR \"surrey\" OR \"Surrey\" OR \"VANCOUVER\" OR \"SURREY\" OR \"BURNABY\" OR \"Victoria\")"
        if not profession:
            profession = query
        if not phonecode:
            phonecode = query
        if not start_date:
            start_date = "01/01/2024"
        
        end_date = datetime.now().strftime("%m/%d/%Y")

        search_query = f"site:{site} \"{query}\" \"{city}\" \"{profession}\" \"({phonecode})\" (\"@gmail.com\" OR \"@yahoo.com\" OR \"@outlook.com\" OR \"@hotmail.com\" OR \"@aol.com\" OR \"@protonmail.com\" OR \"@shaw.ca\" OR \"@zoho.com\" OR \"contact\" OR \"email\" OR \"about us\" OR \"business\" OR \"company\" OR \"get in touch\")&tbs=cdr:1,cd_min:{start_date},cd_max:{end_date}"
        search_box.send_keys(search_query)
        search_box.send_keys(Keys.RETURN)

        if progress_callback:
            progress_callback({"progress": 10, "current_page": 1, "total_pages": "unknown"})

        handle_recaptcha(driver, api)
        time.sleep(2)

        define_timetoexecute(driver, api)
        actions = ActionChains(driver)

        all_tables = []
        next_page = 2
        page_xpath = f'//a[@aria-label="Page {next_page}"]'
        total_pages = None

        try:
            last_page_link = driver.find_elements(By.XPATH, '//a[@aria-label][contains(@aria-label, "Page ")]')[-1]
            total_pages = int(last_page_link.get_attribute("aria-label").split("Page ")[1]) * 2.6
        except:
            total_pages = 26

        while True:
            try:
                time.sleep(2)
                scraped_content = driver.execute_script("return document.body.innerText")

                if progress_callback:
                    progress = min(10 + ((next_page - 1) * 80 / total_pages), 90)
                    progress_callback({"progress": progress, "current_page": next_page - 1, "total_pages": total_pages})

                prompt = (
                    f"Organize this input into a markdown table with columns: | Name | Email | Company | Address | Number | City |. "
                    f"Do not include entries suspicious of being scams (e.g., numbers not in North America). "
                    f"Just fill the information you have from this input:\n\n{scraped_content}"
                )
                table_response = call_openrouter_api(prompt)
                if table_response:
                    all_tables.append(table_response)
                    print(f"Processed page {next_page - 1} into table.")

                try:
                    pagination_link = driver.find_element(By.XPATH, page_xpath)
                    print(f"Clicking on Page {next_page}")
                    pagination_link.click()
                    time.sleep(2)
                    handle_recaptcha(driver, api)
                    next_page += 1
                    page_xpath = f'//a[@aria-label="Page {next_page}"]'
                except NoSuchElementException:
                    print(f"Reached the end of pagination at Page {next_page - 1}")
                    break

            except Exception as e:
                print(f"Unexpected error on Page {next_page}: {e}")
                break

        if all_tables:
            if progress_callback:
                progress_callback({"progress": 95, "current_page": next_page - 1, "total_pages": total_pages})
            final_prompt = (
                "Combine all these tables into one big markdown table. Ensure no information is lost from the tables provided. . Include all information in the table from the past tables but dont start the table with the title header including: Name, Email, etc. or any lines such as '-------', just start immediately from the first row of data with the first information in it with no header or title above it!!"
                "There should be almost 100 rows if data is available, if no data is available just dont send fake or example data. Exclude rows that only have a city with no other information. "
                "Here are the tables:\n\n" + "\n\n".join(all_tables)
            )
            final_table = call_openrouter_api(final_prompt)
            if final_table:
                print("Combined all tables successfully.")
                save_to_database(api, final_table)
            else:
                print("Failed to combine tables.")
        else:
            print("No tables generated from scraped data.")

        if progress_callback:
            progress_callback({"progress": 100, "current_page": next_page - 1, "total_pages": total_pages})
        print("Script completed successfully.")

    finally:
        try:
            driver.quit()
            print("Chrome driver closed.")
        except Exception as e:
            print(f"Error closing Chrome driver: {e}")
        
        time.sleep(2)