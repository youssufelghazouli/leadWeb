import imaplib
import email
from email.header import decode_header
import sqlite3
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage

# Gmail credentials
GMAIL_USER = "smartleadsproduction@gmail.com"
GMAIL_PASS = "fhrccajtlxlaegle"

def check_if_email_sent(recipient_email):
    """
    Check if an email has already been sent to the recipient by searching the Gmail Sent folder.
    Returns True if an email was sent, False otherwise.
    """
    IMAP_SERVER = "imap.gmail.com"
    try:
        # Connect to Gmail IMAP server
        mail = imaplib.IMAP4_SSL(IMAP_SERVER)
        mail.login(GMAIL_USER, GMAIL_PASS)
        # Select the Sent folder (Gmail labels it as "[Gmail]/Sent Mail")
        mail.select('"[Gmail]/Sent Mail"')
        
        # Search for emails sent to the recipient
        status, data = mail.search(None, f'TO "{recipient_email}"')
        if status != "OK":
            mail.logout()
            return False
        
        email_ids = data[0].split()
        if email_ids:  # If there are any emails sent to this recipient
            mail.logout()
            return True
        
        mail.logout()
        return False
    
    except Exception as e:
        print(f"Error checking sent emails for {recipient_email}: {e}")
        return False

def send_email_to_lead(email, name, lead_id, table_name, conn, cursor):
    """
    Helper function to send a consent email and update the consent status in the specified table.
    """
    # Check if an email has already been sent to this email address
    if check_if_email_sent(email):
        # Update status to "Requested" to enable "Check Approval" button
        cursor.execute(f"UPDATE {table_name} SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
        conn.commit()
        return {"status": "success", "message": f"Consent request already sent for lead ID {lead_id} (email: {email})"}
    
    sender = GMAIL_USER
    # Evaluate the greeting before formatting the string
    greeting = name or 'there'
    
    consent_message_html = """
    <!DOCTYPE html>
    <html>
    <body style="font-family: Arial, sans-serif; color: #333; line-height: 1.6;">
        <div style="max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e0e0e0; border-radius: 8px; background-color: #f9f9f9;">
            <div style="text-align: center;">
                <img src="cid:websiteimage" alt="SmartLeads Logo" style="max-width: 150px; margin-bottom: 20px;">
            </div>

            <p>Hi {greeting},</p>

            <p>I hope you’re doing well!</p>

            <p>We are reaching out because our SmartLeads app noticed you might be exploring property options online and one of our real estate partners would like to help.</p>

            <p>We connect people with trusted realtors who can help with:</p>
            <ul>
                <li>Selling, renting, or managing property</li>
                <li>Sharing tailored offers</li>
            </ul>
            <p>All at no cost to you.</p>

            <p>We’d love to assist and connect a real estate agent to you, but only with your permission. Please reply with:</p>
            <ul>
                <li><strong>'Yes'</strong> if you’re interested</li>
                <li><strong>'No'</strong> if you’d rather not</li>
            </ul>
            <p>We respect your choice and won’t contact you again otherwise for your convenience.</p>

            <p>Thanks,<br>SmartLeads Team</p>

            <hr style="border: 0; border-top: 1px solid #e0e0e0; margin: 20px 0;">
            <p style="font-size: 0.9em; color: #555; text-align: center;">
                Are you a realtor or business interested in getting leads without ads? Visit <a href="https://salesfinderai.com" style="color: #3498db; text-decoration: none;">salesfinderai.com</a> to learn more about SmartLeads and our AI-powered social media and client intent searching.
            </p>
        </div>
    </body>
    </html>
    """
    
    consent_message_plain = (
        f"Hi {greeting},\n\n"
        "I hope you’re doing well!\n\n"
        "We reaching out because our SmartLeads app noticed you might be exploring property options online and one of our real estate partners would like to help.\n\n"
        "We connect people with trusted realtors who can help with:\n"
        "- Selling, renting, or managing property\n"
        "- Sharing tailored offers\n\n"
        "All at no cost to you.\n\n"
        "We’d love to assist and connect a real estate agent to you, but only with your permission. Please reply with:\n"
        "- 'Yes' if you’re interested\n"
        "- 'No' if you’d rather not\n\n"
        "We respect your choice and won’t contact you again otherwise for your convenience.\n\n"
        "Thanks,\nSmartLeads Team\n\n"
        "----------------------------------------\n"
        "Are you a realtor or business interested in getting leads without ads? Visit https://salesfinderai.com to learn more about SmartLeads and our AI-powered social media and client intent searching.\n"
    )
    
    # Format the messages with the computed greeting
    formatted_message_html = consent_message_html.format(greeting=greeting)
    formatted_message_plain = consent_message_plain.format(greeting=greeting)
    
    # Create a multipart message to support both plain text and HTML with embedded image
    msg = MIMEMultipart('alternative')
    msg_related = MIMEMultipart('related')
    msg['Subject'] = "May We Assist You with Property Options?"
    msg['From'] = sender
    msg['To'] = email

    # Add plain text part (fallback for clients that don't support HTML)
    plain_part = MIMEText(formatted_message_plain, 'plain')
    msg.attach(plain_part)

    # Add HTML part with embedded image
    html_part = MIMEText(formatted_message_html, 'html')
    msg_related.attach(html_part)

    # Attach the image to the related part
    try:
        with open('websiteimage.png', 'rb') as img_file:
            img = MIMEImage(img_file.read())
            img.add_header('Content-ID', '<websiteimage>')
            img.add_header('Content-Disposition', 'inline', filename='websiteimage.png')
            msg_related.attach(img)
    except FileNotFoundError:
        print("Warning: websiteimage.png not found. Sending email without the image.")
    except Exception as e:
        print(f"Warning: Failed to attach image: {e}")

    # Attach the related part (HTML + image) to the main message
    msg.attach(msg_related)

    try:
        print(f"Attempting to send email to {email} with sender {sender}")
        # Use Gmail's SMTP server
        with smtplib.SMTP('smtp.gmail.com', 587) as server:
            print("Connecting to SMTP server...")
            server.starttls()  # Enable TLS
            print("TLS enabled. Logging in...")
            server.login(GMAIL_USER, GMAIL_PASS)  # Login to Gmail
            print("Login successful. Sending email...")
            server.sendmail(sender, [email], msg.as_string())  # Send email
            print("Email sent successfully.")
        # Update status to "Requested" only if email is sent successfully
        cursor.execute(f"UPDATE {table_name} SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
        conn.commit()
        return {"status": "success", "message": f"Consent email sent to {email} for lead ID {lead_id}"}
    except smtplib.SMTPAuthenticationError as e:
        print(f"Authentication error: {e}")
        return {"status": "error", "message": f"Failed to send email to {email}: Authentication failed. Check GMAIL_USER and GMAIL_PASS."}
    except smtplib.SMTPConnectError as e:
        print(f"Connection error: {e}")
        return {"status": "error", "message": f"Failed to send email to {email}: Could not connect to SMTP server."}
    except Exception as e:
        print(f"Unexpected error: {e}")
        return {"status": "error", "message": f"Failed to send email to {email}: {e}"}
    
def send_email_consent(api, lead_id):
    access_check = api.check_access_restriction()
    if access_check['status'] != 'success':
        return access_check
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()

    # First, check the manual_consents table
    cursor.execute("SELECT email, name, consent_status FROM manual_consents WHERE id = ?", (lead_id,))
    result = cursor.fetchone()
    if result and result[0]:
        email, name, consent_status = result
        table_name = "manual_consents"
    else:
        # If not found in manual_consents, check the leads table
        cursor.execute("SELECT email, name, consent_status FROM leads WHERE id = ?", (lead_id,))
        result = cursor.fetchone()
        if not result or not result[0]:
            conn.close()
            return {"status": "error", "message": f"No email found for lead ID {lead_id}"}
        email, name, consent_status = result
        table_name = "leads"

    # Validate the email address (check for None, empty, or invalid formats like "N/A")
    if not email or '@' not in email:
        conn.close()
        return {"status": "error", "message": "Invalid Email: Cannot Send Consent Request. Please use our Send Email Consent feature if you have a valid email to send to."}

    # Check if consent has already been requested
    if consent_status == 'Requested':
        conn.close()
        return {"status": "error", "message": f"Consent request already sent for lead ID {lead_id}"}

    # Send the email and update the status
    response = send_email_to_lead(email, name, lead_id, table_name, conn, cursor)
    conn.close()
    return response

def check_email_consent(api, lead_id):
    access_check = api.check_access_restriction()
    if access_check['status'] != 'success':
        return access_check
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()

    # First, check the manual_consents table
    cursor.execute("SELECT email, consent_status FROM manual_consents WHERE id = ?", (lead_id,))
    result = cursor.fetchone()
    if result and result[0]:
        email_addr, current_status = result
        table_name = "manual_consents"
    else:
        # If not found in manual_consents, check the leads table
        cursor.execute("SELECT email, consent_status FROM leads WHERE id = ?", (lead_id,))
        result = cursor.fetchone()
        if not result or not result[0]:
            conn.close()
            return {"status": "error", "message": f"No email found for lead ID {lead_id}"}
        email_addr, current_status = result
        table_name = "leads"

    if current_status in ["Granted", "Denied"]:
        conn.close()
        return {"status": "success", "message": f"Consent already finalized for {email_addr}: {current_status}"}
    
    # Gmail IMAP server settings
    IMAP_SERVER = "imap.gmail.com"
    try:
        # Connect to Gmail IMAP server
        mail = imaplib.IMAP4_SSL(IMAP_SERVER)
        mail.login(GMAIL_USER, GMAIL_PASS)
        mail.select("inbox")
        
        # Search for emails from this lead
        status, data = mail.search(None, f'FROM "{email_addr}"')
        if status != "OK":
            mail.logout()
            conn.close()
            return {"status": "success", "message": f"No replies found from {email_addr} yet; status remains {current_status}"}
        
        email_ids = data[0].split()
        if not email_ids:
            mail.logout()
            conn.close()
            return {"status": "success", "message": f"No replies found from {email_addr} yet; status remains {current_status}"}
        
        # Get the latest email
        latest_email_id = email_ids[-1]
        status, msg_data = mail.fetch(latest_email_id, "(RFC822)")
        if status != "OK":
            mail.logout()
            conn.close()
            return {"status": "error", "message": f"Failed to fetch email from {email_addr}"}
        
        raw_email = msg_data[0][1]
        msg = email.message_from_bytes(raw_email)
        subject, encoding = decode_header(msg["Subject"])[0]
        if isinstance(subject, bytes):
            subject = subject.decode(encoding or "utf-8")
        
        # Extract email body
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    body = part.get_payload(decode=True).decode()
                    break
        else:
            body = msg.get_payload(decode=True).decode()
            
      # Split the body to get content before the quoted email
        split_markers = [
            f"<{GMAIL_USER}>",
            "wrote:",
            "--",
            "> ",
        ]
        reply = body
        for marker in split_markers:
            if marker.lower() in body.lower():
                reply = body[:body.lower().index(marker.lower())].strip()
                print(f"Split at marker '{marker}'; extracted reply:\n{reply}")
                break
        else:
            print(f"No split marker found in body; using full body (first line only)")
        
        # Process only the first line to avoid signatures or extra text
        reply = reply.split('\n')[0].strip().lower()
        print(f"Processed reply from {email_addr}: '{reply}'")
        
        # Check for consent
        if "yes" in reply and "no" not in reply:
            new_status = "Granted"
        elif "no" in reply and "yes" not in reply:
            new_status = "Denied"
        else:
            new_status = "Pending"
        
        if new_status in ["Granted", "Denied"]:
            cursor.execute(f"UPDATE {table_name} SET consent_status = ? WHERE id = ?", (new_status, lead_id))
            conn.commit()
            conn.close()
            mail.logout()
            return {"status": "success", "message": f"Consent status updated for {email_addr}: {new_status}"}
        else:
            conn.close()
            mail.logout()
            return {"status": "success", "message": f"No conclusive reply from {email_addr} yet; status remains {current_status}"}
    
    except Exception as e:
        conn.close()
        return {"status": "error", "message": f"Error checking consent for {email_addr}: {e}"}