import os
import sys
import time
import shutil
from seleniumwire import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, NoSuchElementException
import sqlite3
from SecondAutomation import make_transparent, handle_recaptcha  # Import shared functions
from ad_generator import login_to_instagram
import tkinter as tk
from tkinter import messagebox

# Instagram login credentials (same as in your original script)
INSTAGRAM_USERNAME = "SmartSalesFinderAI"
INSTAGRAM_PASSWORD = "thesmartleadsproject123!"

# Proxy credentials and settings
PROXY_HOST = "isp.oxylabs.io"
PROXY_PORT = 8001
PROXY_USER = "smartleads_ffSW0"
PROXY_PASS = "SmartleadsProduct123_"

def not_now_button(driver):
    try:
            not_now_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((
                    By.XPATH, "//button[contains(@class, '_a9--') and contains(@class, '_ap36') and contains(@class, '_a9_1')][text()='Not Now']"
                ))
            )
            not_now_button.click()
            time.sleep(4)  # Wait for the dialog to dismiss
            print(f"Clicked 'Not Now' button")
    except TimeoutException:
            print(f"No 'Not Now' button found, proceeding without it")

def search_instagram_username(driver, username):
    try:

        search_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.CSS_SELECTOR, "svg[aria-label='Search']"))
        )
        search_button.click()
        time.sleep(1)  # Brief wait for the search input to appear

        # Locate the search bar
        search_bar = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[@placeholder='Search']"))
        )
        search_bar.clear()
        search_bar.send_keys(username)
        search_bar.send_keys(Keys.RETURN)
        time.sleep(6)

        spans = WebDriverWait(driver, 10).until(
            EC.presence_of_all_elements_located((
                By.XPATH, f"//span[contains(@class, 'x1lliihq') and contains(@class, 'x1plvlek') and contains(@class, 'xryxfnj') and contains(@class, 'x1n2onr6') and contains(@class, 'x193iq5w')][text()='{username}']"
            ))
        )
        if not spans:
            print(f"No matching <span> elements found for username: {username}")
            return False
        
        print(f"Found {len(spans)} matching <span> elements for username: {username}")
        spans[0].click()  # Click the first one
        time.sleep(6)  # Wait for the profile page to load

        # Check if the username exists by looking for the profile link
        profile_link = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, f"//a[@href='/{username}/']"))
        )
        print(f"Found Instagram profile for username: {username}")

        try:
            message_button = WebDriverWait(driver, 5).until(
                EC.element_to_be_clickable((
                    By.XPATH, "//div[contains(@class, 'x1i10hfl') and contains(@class, 'xjqpnuy') and contains(@class, 'xa49m3k')][text()='Message']"
                ))
            )
            message_button.click()
            time.sleep(6)  # Wait for the message interface to load

            print(f"Clicked 'Message' button for username: {username}")
        except TimeoutException:
            print(f"No 'Message' button found for username: {username}, falling back to 'Send message' button")

            # Locate and click the "Send message" button
            options_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.CSS_SELECTOR, "svg[aria-label='Options']"))
            )
            options_button.click()
            time.sleep(6)  # Wait for the options menu to load

            send_message_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((
                    By.XPATH, "//button[contains(@class, 'xjbqb8w') and contains(@class, 'x1qhh985') and contains(@class, 'xcfux6l')][text()='Send message']"
                ))
            )
            send_message_button.click()
            time.sleep(6)  # Wait for the message interface to load
            
            print(f"Clicked 'Send message' button for username: {username}")

        not_now_button(driver)  # Call the function to click "Not Now" if it appears

        return True
    except TimeoutException:
        print(f"Could not find Instagram profile for username: {username}")
        return False
    except Exception as e:
        print(f"Error searching for username {username}: {e}")
        return False

def send_consent_request(api, lead_id, table_name="instagram_leads"):
    access_check = api.check_access_restriction()
    if access_check['status'] != 'success':
        return access_check
    # Connect to the database
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()
    
    # Fetch the username for the given lead_id from the specified table
    cursor.execute(f"SELECT username FROM {table_name} WHERE id = ?", (lead_id,))
    result = cursor.fetchone()
    if not result or not result[0]:
        conn.close()
        return {"status": "error", "message": f"No username found for lead ID {lead_id} in {table_name}"}
    
    username = result[0]
    
    # Set up Selenium WebDriver
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--start-maximized")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_argument("--incognito")
    options.add_argument("--disable-save-password-bubble")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    # Selenium Wire proxy config
    seleniumwire_options = {
        'proxy': {
            'http': f'http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'https': f'https://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'no_proxy': 'localhost,127.0.0.1'
        }
    }

    driver = webdriver.Chrome(options=options, seleniumwire_options=seleniumwire_options)

    try:
        login_to_instagram(driver)
        
        # Search for the username
        if search_instagram_username(driver, username):
            message_input = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((
                    By.XPATH, "//p[contains(@class, 'xat24cr') and contains(@class, 'xdj266r')]"
                ))
            )
            message_input.click()

            consent_message = (
                f"Hi, I hope you’re doing well! We're reaching out because our SmartLeads app noticed you might be "
                "exploring property options online and one of our real estate partners would like to help. We connect people with trusted realtors who can either help with selling, "
                "renting, or managing property, or share tailored offers that match your interests—all at no cost to you. "
                "We’d love to assist and connect a real estate agent to you, but only with your permission. Could you reply with 'Yes' if you’re interested, or 'No' "
                "if you’d rather not? Either way, we respect your choice and won’t be reaching out to you again for your convenience. Thanks from the SmartLeads Team! Are you a realtor or business interested in getting leads without ads? Visit https://salesfinderai.com to learn more about SmartLeads and our AI-powered social media and client intent searching."
            )

            # Check if the consent message was already sent
            try:
                sent_messages = driver.find_elements(
                    By.XPATH,
                    "//div[contains(@class, 'xexx8yu') and contains(@class, 'x4uap5') and contains(@class, 'x18d9i69') and contains(@class, 'xkhd6sd') and contains(@class, 'x1gslohp') and contains(@class, 'x11i5rnm') and contains(@class, 'x12nagc') and contains(@class, 'x1mh8g0r') and contains(@class, 'x1yc453h') and contains(@class, 'x126k92a') and contains(@class, 'xyk4ms5')]"
                )
                if sent_messages:
                    cursor.execute(f"UPDATE {table_name} SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
                    conn.commit()
                    conn.close()
                    return {"status": "success", "message": f"Consent request already sent for Instagram lead ID {lead_id} (username: {username})"}
            except:
                pass

            message_input.send_keys(consent_message)
            message_input.send_keys(Keys.RETURN)
            time.sleep(2)  # Wait for the input to be active
            print(f"Clicked message input area for username: {username}")

            time.sleep(30)
            cursor.execute(f"UPDATE {table_name} SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Consent request sent for Instagram lead ID {lead_id} (username: {username})"}
        else:
            conn.close()
            return {"status": "error", "message": f"Could not find Instagram profile for username: {username}"}

    finally:
        try:
            driver.quit()
            print("Chrome driver closed.")
        except Exception as e:
            print(f"Error closing Chrome driver: {e}")
        time.sleep(2)
        
def check_instagram_message_consent(driver, username):
    try:

        received_messages = driver.find_elements(
            By.XPATH, 
            "//div[contains(@class, 'xdj266r') and contains(@class, 'x11i5rnm')]//span[contains(@class, 'x193iq5w')]//div[contains(@class, 'xexx8yu') and contains(@class, 'x4uap5')]"
        )
        
        if not received_messages:
            print(f"No reply found from {username} yet")
            return "Pending"

        # Get the latest received message
        latest_reply = received_messages[-1].text.strip().lower()
        print(f"Latest reply from {username}: '{latest_reply}'")

        # Check for "yes" or "no" in the reply
        if "yes" in latest_reply and "no" not in latest_reply:
            print(f"Consent granted by {username}")
            return "Granted"
        elif "no" in latest_reply and "yes" not in latest_reply:
            print(f"Consent denied by {username}")
            return "Denied"
        else:
            print(f"Reply from {username} is ambiguous or not a clear 'Yes' or 'No'")
            return "Pending"

    except TimeoutException:
        print(f"Could not navigate to message chat for username: {username}")
        return "Pending"
    except Exception as e:
        print(f"Error checking consent for username {username}: {e}")
        return "Pending"



def check_consent_request(api, lead_id, table_name="instagram_leads"):
    access_check = api.check_access_restriction()
    if access_check['status'] != 'success':
        return access_check
    # Connect to the database
    conn = api.connect_to_db('leads.db')
    cursor = conn.cursor()
    
    # Fetch the username and current consent_status for the given lead_id
    cursor.execute(f"SELECT username, consent_status FROM {table_name} WHERE id = ?", (lead_id,))
    result = cursor.fetchone()
    if not result or not result[0]:
        conn.close()
        return {"status": "error", "message": f"No username found for lead ID {lead_id} in {table_name}"}
    
    username, current_status = result
    
    # If already finalized, no need to check further
    if current_status in ["Granted", "Denied"]:
        conn.close()
        return {"status": "success", "message": f"Consent already finalized for {username}: {current_status}"}
    
    # Set up Selenium WebDriver
    options = Options()
    options.add_argument("--disable-blink-features=AutomationControlled")
    options.add_argument("--disable-popup-blocking")
    options.add_argument("--start-maximized")
    options.add_experimental_option("useAutomationExtension", False)
    options.add_argument("--incognito")
    options.add_argument("--disable-save-password-bubble")
    options.add_experimental_option("excludeSwitches", ["enable-automation"])

    # Selenium Wire proxy config
    seleniumwire_options = {
        'proxy': {
            'http': f'http://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'https': f'https://{PROXY_USER}:{PROXY_PASS}@{PROXY_HOST}:{PROXY_PORT}',
            'no_proxy': 'localhost,127.0.0.1'
        }
    }

    driver = webdriver.Chrome(options=options, seleniumwire_options=seleniumwire_options)

    try:
        login_to_instagram(driver)
        
        if not search_instagram_username(driver, username):
            conn.close()
            return {"status": "error", "message": f"Could not find Instagram profile for username: {username}"}

        new_status = check_instagram_message_consent(driver, username)
        
        if new_status in ["Granted", "Denied"]:
            cursor.execute(f"UPDATE {table_name} SET consent_status = ? WHERE id = ?", (new_status, lead_id))
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Consent status updated for {username}: {new_status}"}
        else:
            conn.close()
            return {"status": "success", "message": f"No conclusive reply from {username} yet; status remains {current_status}"}

    except Exception as e:
        conn.close()
        return {"status": "error", "message": f"Error checking consent for username {username}: {e}"}
    
    finally:
        try:
            driver.quit()
            print("Chrome driver closed.")
        except Exception as e:
            print(f"Error closing Chrome driver: {e}")
        time.sleep(2)