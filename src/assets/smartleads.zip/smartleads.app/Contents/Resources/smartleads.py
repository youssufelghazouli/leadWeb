import os
import sys
import webview
import json
import getmac
import string
import random
import smtplib
import SecondAutomation
import GoogleMapsScraper
import tkinter as tk
from tkinter import messagebox
from datetime import datetime, timedelta
from chatbot import chatbot_query
import shutil
import time
import sqlite3
import csv
import bcrypt
import ad_generator
import stripe
from sendInstagramConsent import send_consent_request, check_consent_request
from email.mime.text import MIMEText
from sendEmailConsent import send_email_consent, check_email_consent
from stripe_token_manager import StripeTokenManager


class API:
    def __init__(self):
        self.check_stripe_product()
        self._window = None
        self.temp_dir = None
        # Initialize the manual_consents table
        self.current_user = None  # Store current user
        # Initialize database connection
        self.stripe_manager = StripeTokenManager()
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS manual_consents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                email TEXT,
                name TEXT,
                consent_status TEXT
            )
        ''')
        # Initialize the instagram_leads table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS manual_instagram_consents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                username TEXT,
                consent_status TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS verification_codes (
                email TEXT PRIMARY KEY,
                code TEXT,
                purpose TEXT,
                created_at TEXT
            )
        ''')
        conn.commit()
        conn.close()
        self.check_chrome_installed()
    
    def check_chrome_installed(self):
            """Check if Google Chrome is installed in Applications or Desktop, show macOS native dialog if not."""
            try:
                # Define possible locations where Chrome might be
                chrome_locations = [
                    "/Applications/Google Chrome.app",
                    os.path.expanduser("~/Desktop/Google Chrome.app")
                ]
                
                # Check if Chrome is in one of the specified locations
                if not any(os.path.exists(path) for path in chrome_locations):
                    raise FileNotFoundError("Google Chrome not found in Applications or Desktop.")

            except Exception as e:
                SecondAutomation.create_custom_messagebox(
                    title="Chrome Required",
                    message="Google Chrome is required to run SmartLeads. Please install it from https://www.google.com/chrome/ and place it in Applications or Desktop, then restart the app.",
                    api=self
                )
                sys.exit(1)

    def get_resource_path(self, filename):
        if getattr(sys, 'frozen', False):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(base_path, filename)

    def get_db_path(self, db_name):
        if getattr(sys, 'frozen', False):
            app_data_dir = os.path.expanduser('~/Library/Application Support/SmartLeads')
            os.makedirs(app_data_dir, exist_ok=True)
            writable_db_path = os.path.join(app_data_dir, db_name)
            bundled_db_path = self.get_resource_path(db_name)
            if not os.path.exists(writable_db_path) and os.path.exists(bundled_db_path):
                shutil.copy(bundled_db_path, writable_db_path)
            return writable_db_path
        else:
            return os.path.join(os.path.dirname(os.path.abspath(__file__)), db_name)
    
    def connect_to_db(self, db_name):
        db_path = self.get_db_path(db_name)
        try:
            conn = sqlite3.connect(db_path, check_same_thread=False)
            print(f"Connected to {db_name} at {db_path}")
            return conn
        except Exception as e:
            print(f"Error connecting to {db_name}: {e}")
            raise

    def check_stripe_product(self):
        try:
            # Retrieve the Stripe product
            product = stripe.Product.retrieve("prod_SEDZnYu33gF1R0")
            # Check if the product is active
            if not product.active:
                root = tk.Tk()
                root.withdraw()
                messagebox.showerror("Application Error", "This application is temporarily unavailable. Contact support for more details.")
                root.destroy()
                sys.exit(1)
        except stripe.error.InvalidRequestError as e:
            # This error occurs if the product doesn't exist (e.g., deleted)
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Application Error", "This application is no longer available. Contact support for more details.")
            root.destroy()
            sys.exit(1)
        except stripe.error.StripeError as e:
            # Handle other Stripe errors (e.g., authentication issues, network errors)
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Application Error", f"Failed to verify application status: {str(e)}")
            root.destroy()
            sys.exit(1)

    def set_window(self, window):
        self._window = window
        self.temp_dir = getattr(window, '_temp_dir', None) or os.path.join(os.environ.get("TEMP", os.path.expanduser("~\\AppData\\Local\\Temp")), f"tmp{os.urandom(4).hex()}")


    def signup(self, data):
        try:
            credentials = json.loads(data)
            email = credentials.get("email", "").strip()
            username = credentials.get("username", "").strip()
            password = credentials.get("password", "").strip()
            name = credentials.get("name", "").strip()
            stripe_token = credentials.get("stripe_token", "").strip()
            if not email or not username or not password or not name or not stripe_token:
                return {"status": "error", "message": "Email, username, password, name, and card details are required!"}

            # Check if email already exists in Stripe
            customers = stripe.Customer.list(email=email, limit=1)
            if customers.data:
                return {"status": "error", "message": "This email is already registered! Please use a different email or log in."}

            # Retrieve card fingerprint from the token
            card = stripe.Token.retrieve(stripe_token).card
            card_fingerprint = card.fingerprint
            if not card_fingerprint:
                return {"status": "error", "message": "Unable to retrieve card fingerprint!"}

            # Check for existing username and card reuse
            customers = stripe.Customer.list()
            username_exists = False
            for customer in customers.auto_paging_iter():
                # Check username
                if customer.metadata.get("username") == username:
                    username_exists = True
                # Check payment methods (modern Stripe API)
                try:
                    payment_methods = stripe.PaymentMethod.list(
                        customer=customer.id,
                        type='card'
                    )
                    for pm in payment_methods.auto_paging_iter():
                        if pm.card and pm.card.fingerprint and pm.card.fingerprint == card_fingerprint:
                            print(f"Card fingerprint match found for customer {customer.id}, PaymentMethod {pm.id}")  # Debugging
                            return {"status": "error", "message": "This credit card is already registered with another account! Please use a different card."}
                except stripe.error.StripeError as e:
                    print(f"Error checking payment methods for customer {customer.id}: {str(e)}")  # Debugging
                    continue  # Skip customer if payment method retrieval fails

            if username_exists:
                return {"status": "error", "message": "Username already in use!"}

            # Hash password
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')

            # Send verification code
            code = ''.join(random.choices(string.digits, k=6))
            response = self.send_verification_email(email, name, code, "signup")
            if response["status"] == "error":
                return response

            # Store verification code
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute(
                'INSERT OR REPLACE INTO verification_codes (email, code, purpose, created_at) VALUES (?, ?, ?, ?)',
                (email, code, "signup", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            )
            conn.commit()
            conn.close()

            return {
                "status": "success",
                "message": f"Verification code sent to {email}. Please check your inbox.",
                "action": "verify_email",
                "email": email
            }
        except stripe.error.StripeError as e:
            print(f"Stripe error during signup: {str(e)}")  # Debugging
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            print(f"Unexpected error during signup: {str(e)}")  # Debugging
            return {"status": "error", "message": f"Signup error: {str(e)}"}
    
    def verify_login(self, data):
        try:
            credentials = json.loads(data)
            username = credentials.get("username", "").strip()
            password = credentials.get("password", "").strip()
            if not username or not password:
                return {"status": "error", "message": "Username and password are required!"}

            # Check Stripe for customer with username
            customers = stripe.Customer.list()  # Removed limit to iterate over all customers
            user_email = None
            customer_name = None
            hashed_password = None
            for customer in customers.auto_paging_iter():
                if customer.metadata.get("username") == username:
                    user_email = customer.email
                    customer_name = customer.metadata.get("name", username)
                    hashed_password = customer.metadata.get("password")
                    break
            if not user_email:
                return {"status": "error", "message": "Invalid username!"}
            if not hashed_password:
                return {"status": "error", "message": "No password set for this account. Please reset your password.", "action": "forgot_password"}

            # Verify password
            if bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8')):
                self.current_user = user_email
                return {"status": "success", "message": f"Welcome, {customer_name}!"}
            return {"status": "error", "message": "Invalid password!"}
        except json.JSONDecodeError:
            return {"status": "error", "message": "Invalid login data!"}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Login error: {str(e)}"}
    
    def forgot_password(self, data):
        try:
            data = json.loads(data)
            email = data.get("email", "").strip()
            if not email:
                return {"status": "error", "message": "Email is required!"}

            # Check Stripe for customer
            customers = stripe.Customer.list(email=email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "No account found with this email!"}

            customer = customers.data[0]
            name = customer.metadata.get("name", "User")

            # Send reset code
            code = ''.join(random.choices(string.digits, k=6))
            response = self.send_verification_email(email, name, code, "reset_password")
            if response["status"] == "error":
                return response

            # Store reset code
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute(
                'INSERT OR REPLACE INTO verification_codes (email, code, purpose, created_at) VALUES (?, ?, ?, ?)',
                (email, code, "reset_password", datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            )
            conn.commit()
            conn.close()

            return {
                "status": "success",
                "message": f"Password reset code sent to {email}. Please check your inbox.",
                "action": "reset_password",
                "email": email
            }
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Error: {str(e)}"}

    def reset_password(self, data):
        try:
            data = json.loads(data)
            email = data.get("email", "").strip()
            code = data.get("code", "").strip()
            new_password = data.get("new_password", "").strip()
            if not email or not code or not new_password:
                return {"status": "error", "message": "Email, code, and new password are required!"}

            # Verify code
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute('SELECT code, created_at FROM verification_codes WHERE email = ? AND purpose = ?', (email, "reset_password"))
            result = cursor.fetchone()
            if not result:
                conn.close()
                return {"status": "error", "message": "No reset code found for this email!"}

            stored_code, created_at = result
            created_time = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
            if datetime.now() > created_time + timedelta(minutes=15):
                cursor.execute('DELETE FROM verification_codes WHERE email = ?', (email,))
                conn.commit()
                conn.close()
                return {"status": "error", "message": "Reset code has expired!"}

            if code != stored_code:
                conn.close()
                return {"status": "error", "message": "Invalid reset code!"}

            # Update password in Stripe
            customers = stripe.Customer.list(email=email, limit=1)
            if not customers.data:
                conn.close()
                return {"status": "error", "message": "No account found with this email!"}

            customer_id = customers.data[0].id
            hashed_password = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            stripe.Customer.modify(
                customer_id,
                metadata={'password': hashed_password}
            )

            # Clear reset code
            cursor.execute('DELETE FROM verification_codes WHERE email = ?', (email,))
            conn.commit()
            conn.close()

            return {"status": "success", "message": "Password reset successfully! Please log in with your new password."}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Error: {str(e)}"}

    def send_verification_email(self, email, name, code, purpose):
        GMAIL_USER = "smartleadsproduction@gmail.com"  # Replace with your Gmail address
        GMAIL_PASS = "fhrccajtlxlaegle"
        sender = GMAIL_USER
        message = (
            f"Hi {name or 'there'},\n\n"
            f"Your {purpose.replace('_', ' ').title()} verification code for SmartLeads is: {code}\n\n"
            "Please enter this code in the app to proceed. This code will expire in 15 minutes.\n\n"
            "Thanks,\nSmartLeads Team"
        )
        msg = MIMEText(message)
        msg['Subject'] = f"SmartLeads Search {purpose.replace('_', ' ').title()} Verification Code"
        msg['From'] = sender
        msg['To'] = email

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(GMAIL_USER, GMAIL_PASS)
                server.sendmail(sender, [email], msg.as_string())
            return {"status": "success", "message": f"Email sent to {email}"}
        except Exception as e:
            return {"status": "error", "message": f"Failed to send email to {email}: {e}"}

    def send_confirmation_email(self, email, name, subject, body):
        GMAIL_USER = "smartleadsproduction@gmail.com"
        GMAIL_PASS = "fhrccajtlxlaegle"
        sender = GMAIL_USER
        msg = MIMEText(body)
        msg['Subject'] = subject
        msg['From'] = sender
        msg['To'] = email

        try:
            with smtplib.SMTP('smtp.gmail.com', 587) as server:
                server.starttls()
                server.login(GMAIL_USER, GMAIL_PASS)
                server.sendmail(sender, [email], msg.as_string())
            return {"status": "success", "message": f"Confirmation email sent to {email}"}
        except Exception as e:
            return {"status": "error", "message": f"Failed to send confirmation email to {email}: {e}"}

    def verify_email_code(self, data):
        try:
            data = json.loads(data)
            email = data.get("email", "").strip()
            code = data.get("code", "").strip()
            username = data.get("username", "").strip()
            password = data.get("password", "").strip()
            name = data.get("name", "").strip()
            stripe_token = data.get("stripe_token", "").strip()
            if not email or not code or not username or not password or not name or not stripe_token:
                return {"status": "error", "message": "Email, code, username, password, name, and card details are required!"}

            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute('SELECT code, created_at FROM verification_codes WHERE email = ? AND purpose = ?', (email, "signup"))
            result = cursor.fetchone()
            if not result:
                conn.close()
                return {"status": "error", "message": "No verification code found for this email!"}

            stored_code, created_at = result
            created_time = datetime.strptime(created_at, "%Y-%m-%d %H:%M:%S")
            if datetime.now() > created_time + timedelta(minutes=15):
                cursor.execute('DELETE FROM verification_codes WHERE email = ?', (email,))
                conn.commit()
                conn.close()
                return {"status": "error", "message": "Verification code has expired!"}

            if code != stored_code:
                conn.close()
                return {"status": "error", "message": "Invalid verification code!"}

            # Check if email is already associated with a customer
            customers = stripe.Customer.list(email=email, limit=1)
            if customers.data:
                conn.close()
                return {"status": "error", "message": "This email is already registered! Please use a different email."}

            # Validate card with $0 authorization using SetupIntent
            setup_intent = stripe.SetupIntent.create(
                payment_method_data={
                    'type': 'card',
                    'card': {
                        'token': stripe_token
                    }
                },
                confirm=True,
                usage='off_session',
                automatic_payment_methods={
                    'enabled': True,
                    'allow_redirects': 'never'
                }
            )

            if setup_intent.status != 'succeeded':
                conn.close()
                return {"status": "error", "message": "Card validation failed. Please use a valid card."}

            # Get the PaymentMethod from the SetupIntent
            payment_method_id = setup_intent.payment_method

            # Create customer
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
            customer = stripe.Customer.create(
                email=email,
                name=name,
                metadata={
                    'username': username,
                    'name': name,
                    'password': hashed_password,
                    'token_balance': 6000,
                    'subscription_status': 'trial',
                    'subscription_start': datetime.now().date().strftime("%Y-%m-%d"),
                    'last_reset_date': datetime.now().date().strftime("%Y-%m-%d")
                }
            )

            # Attach the PaymentMethod to the customer
            stripe.PaymentMethod.attach(
                payment_method_id,
                customer=customer.id
            )

            # Set the PaymentMethod as the default
            stripe.Customer.modify(
                customer.id,
                invoice_settings={
                    'default_payment_method': payment_method_id
                }
            )

            # Create subscription with trial
            subscription = stripe.Subscription.create(
                customer=customer.id,
                items=[{'price': 'price_1RJl8CB310pZ8hVHj1ULqclV'}],
                trial_period_days=3
            )

            cursor.execute('DELETE FROM verification_codes WHERE email = ?', (email,))
            conn.commit()
            conn.close()

            # Send trial confirmation email
            trial_end = datetime.fromtimestamp(subscription.trial_end).strftime('%Y-%m-%d')
            subject = "Welcome to SmartLeads! Your Trial Has Started"
            body = (
                f"Hi {name},\n\n"
                f"Welcome to SmartLeads! Your 3-day free trial has started with 6,000 tokens.\n\n"
                f"Trial Details:\n"
                f"- Tokens: 6,000\n"
                f"- Trial End Date: {trial_end}\n\n"
                f"Start exploring now and make the most of your trial!\n\n"
                f"Best,\nSmartLeads Team"
            )
            email_response = self.send_confirmation_email(email, name, subject, body)
            if email_response["status"] == "error":
                print(email_response["message"])

            self.current_user = email
            return {"status": "success", "message": f"Welcome, {name}! Your 3-day free trial with 6,000 tokens has started."}
        except stripe.error.CardError as e:
            conn.close()
            return {"status": "error", "message": f"Card validation failed: Please use a valid card."}
        except stripe.error.InvalidRequestError as e:
            conn.close()
            if "token has already been used" in str(e) or "You cannot use a Stripe token more than once" in str(e):
                return {"status": "error", "message": "This card token has already been used. Please re-enter your card details to generate a new token."}
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except stripe.error.StripeError as e:
            conn.close()
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            conn.close()
            return {"status": "error", "message": f"Error: {str(e)}"}
      
    def purchase_tokens(self, data):
        try:
            data = json.loads(data)
            stripe_token = data['stripe_token']
            quantity = data['quantity']
            amount = data['amount']
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            return self.stripe_manager.purchase_tokens(user_email, stripe_token, quantity, amount)
        except Exception as e:
            return {"status": "error", "message": f"Purchase error: {str(e)}"}

    def start_subscription(self, data):
        try:
            data = json.loads(data)
            stripe_token = data['stripe_token']
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            response = self.stripe_manager.start_subscription(user_email, stripe_token)
            if response['status'] == 'success':
                # Update customer metadata with username and initial token balance
                customers = stripe.Customer.list(email=user_email, limit=1)
                if not customers.data:
                    return {"status": "error", "message": "Customer not found after subscription start!"}
                customer = customers.data[0]
                customer_metadata = customer.metadata or {}
                # Set initial token balance and subscription status if not already set
                if not customer_metadata.get("token_balance"):
                    customer_metadata["token_balance"] = 100000  # Initial 100,000 tokens
                if not customer_metadata.get("subscription_status"):
                    customer_metadata["subscription_status"] = "active"
                if not customer_metadata.get("username"):
                    conn = self.connect_to_db('leads.db')
                    cursor = conn.cursor()
                    cursor.execute('SELECT email FROM users WHERE email = ?', (user_email,))
                    if cursor.fetchone():
                        customer_metadata["username"] = user_email
                    conn.close()
                stripe.Customer.modify(
                    customer.id,
                    metadata=customer_metadata
                )
            return response
        except Exception as e:
            return {"status": "error", "message": f"Subscription error: {str(e)}"}
    
    def check_subscription(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            # Use stripe_manager to get raw subscription status
            raw_response = self.stripe_manager.check_subscription(user_email)
            if raw_response['status'] != 'success':
                return raw_response
            # Get customer metadata for app-specific subscription status
            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            app_subscription_status = customer.metadata.get("subscription_status", "none")
            # Combine raw subscription status with app-specific status
            return {
                "status": "success",
                "subscription_status": app_subscription_status,
                "raw_subscription_status": raw_response.get("subscription_status")
            }
        except Exception as e:
            return {"status": "error", "message": f"Check subscription error: {str(e)}"}
        
    def check_subscription_status(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            subscription_status = customer.metadata.get("subscription_status", "none")
            return {"status": "success", "subscription_status": subscription_status}
        except Exception as e:
            return {"status": "error", "message": f"Check subscription status error: {str(e)}"}
        
    def check_tokens(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            token_balance = int(customer.metadata.get("token_balance", 0))
            return {"status": "success", "balance": token_balance}
        except Exception as e:
            return {"status": "error", "message": f"Check tokens error: {str(e)}"}

    def consume_token(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            return self.stripe_manager.consume_token(user_email)
        except Exception as e:
            return {"status": "error", "message": f"Consume token error: {str(e)}"}

    def check_trial_token_usage(self, requested_tokens):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}

            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id

            subscriptions = stripe.Subscription.list(customer=customer_id, status='all', limit=1)
            if not subscriptions.data:
                return {"status": "error", "message": "No subscription found for user!"}
            subscription = subscriptions.data[0]

            subscription_status = customer.metadata.get("subscription_status", "none")
            current_balance = int(customer.metadata.get("token_balance", 0))
            subscription_start = customer.metadata.get("subscription_start", datetime.now().strftime("%Y-%m-%d"))

            if subscription_status != 'trial':
                return {"status": "success", "proceed": True, "balance": current_balance}

            sub_start = datetime.strptime(subscription_start, "%Y-%m-%d").date()
            today = datetime.now().date()
            if today > sub_start + timedelta(days=3):
                if subscription.status == 'active':
                    new_balance = current_balance + 100000
                    stripe.Customer.modify(
                        customer_id,
                        metadata={
                            "token_balance": new_balance,
                            "subscription_status": "active",
                            "subscription_start": subscription_start,
                            "last_reset_date": customer.metadata.get("last_reset_date")
                        }
                    )
                    return {"status": "success", "proceed": True, "balance": new_balance}

            total_tokens_used = 6000 - current_balance
            if total_tokens_used + requested_tokens > 6000:
                return {
                    "status": "error",
                    "message": "Trial token limit exceeded! You can only use 6,000 tokens during the trial. Proceed to start your subscription early and get 100,000 tokens?",
                    "action_required": "confirm_subscription_start",
                    "current_balance": current_balance
                }

            return {"status": "success", "proceed": True, "balance": current_balance}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Check trial token usage error: {str(e)}"}
    
    def confirm_early_subscription_start(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}

            customers = stripe.Customer.list(email=user_email, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            customer_id = customer.id

            subscriptions = stripe.Subscription.list(customer=customer_id, status='all', limit=1)
            if not subscriptions.data:
                return {"status": "error", "message": "No subscription found for user!"}
            subscription = subscriptions.data[0]
            subscription_id = subscription.id

            subscription_status = customer.metadata.get("subscription_status", "none")
            current_balance = int(customer.metadata.get("token_balance", 0))
            if subscription_status != 'trial':
                return {"status": "error", "message": "User is not in trial mode!"}

            stripe.Subscription.modify(
                subscription_id,
                trial_end='now'
            )

            new_balance = current_balance + 100000
            stripe.Customer.modify(
                customer_id,
                metadata={
                    "token_balance": new_balance,
                    "subscription_status": "active",
                    "subscription_start": customer.metadata.get("subscription_start"),
                    "last_reset_date": customer.metadata.get("last_reset_date")
                }
            )

            return {"status": "success", "message": f"Subscription started early! You now have {new_balance} tokens."}
        except stripe.error.StripeError as e:
            return {"status": "error", "message": f"Stripe error: {str(e)}"}
        except Exception as e:
            return {"status": "error", "message": f"Early subscription start error: {str(e)}"}
    
    def cancel_subscription(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            response = self.stripe_manager.cancel_subscription(user_email)
            if response['status'] == 'success':
                # Ensure customer metadata reflects the canceled state
                customers = stripe.Customer.list(email=user_email, limit=1)
                if customers.data:
                    customer = customers.data[0]
                    stripe.Customer.modify(
                        customer.id,
                        metadata={
                            "token_balance": customer.metadata.get("token_balance", 0),
                            "subscription_status": "canceled",
                            "subscription_start": customer.metadata.get("subscription_start"),
                            "last_reset_date": customer.metadata.get("last_reset_date")
                        }
                    )
            return response
        except Exception as e:
            return {"status": "error", "message": f"Cancellation error: {str(e)}"}

    def check_access_restriction(self):
        try:
            user_email = self.current_user
            if not user_email:
                return {"status": "error", "message": "No user logged in!"}
            sub_check = self.check_subscription()
            if sub_check['status'] == 'error':
                return sub_check
            if sub_check['subscription_status'] == 'active':
                return {"status": "success", "message": "Access granted (active subscription)"}
            token_check = self.check_tokens()
            if token_check['status'] == 'error':
                return token_check
            if token_check['balance'] > 10000:
                return {"status": "success", "message": "Access granted (>10,000 tokens)"}
            return {"status": "error", "message": "Access denied: Requires active subscription or more than 10,000 tokens."}
        except Exception as e:
            return {"status": "error", "message": f"Access check error: {str(e)}"}
        
    def get_current_user_id(self):
        if not self.current_user:
            raise Exception("No user logged in")
        return self.current_user


    def get_token_balance(self):
        try:
            user_id = self.get_current_user_id()
            customers = stripe.Customer.list(email=user_id, limit=1)
            if not customers.data:
                return {"status": "error", "message": "User not found in Stripe!"}
            customer = customers.data[0]
            token_balance = int(customer.metadata.get("token_balance", 0))
            return {"status": "success", "balance": token_balance}
        except Exception as e:
            return {"status": "error", "message": str(e)}
    
    def update_progress(self, progress_data):
        if self._window:
            try:
                js_code = f"updateProgress({json.dumps(progress_data)})"
                self._window.evaluate_js(js_code)
            except Exception as e:
                print(f"Failed to update progress: {e}")

    def updatelead_progress(self, progress_data):
        if self._window:
            try:
                js_code = f"updateLeadProgress({json.dumps(progress_data)})"
                self._window.evaluate_js(js_code)
            except Exception as e:
                print(f"Failed to update progress: {e}")

    def updatelocallead_progress(self, progress_data):
        if self._window:
            try:
                js_code = f"updateLocalProgress({json.dumps(progress_data)})"
                self._window.evaluate_js(js_code)
            except Exception as e:
                print(f"Failed to update progress: {e}")         

    def run_search(self, data):
        params = json.loads(data)
        site = params.get("site")
        query = params.get("query")
        city = params.get("city", "")
        profession = params.get("profession", "")
        phonecode = params.get("phonecode", "")
        start_date_raw = params.get("start_date", "")
        
        if start_date_raw:
            start_date_raw = start_date_raw.replace("-", "/")
            year, month, day = start_date_raw.split("/")
            start_date = f"{month}/{day}/{year}"
        else:
            start_date = ""

        if not site or not query:
            return {"status": "error", "message": "Site and query are required!"}
        
        # Check token balance before running the search
        search_cost = 2000
        token_check = self.check_tokens()
        if token_check['status'] != 'success':
            return token_check  # Returns error if user not found or Stripe error
        
        balance = token_check['balance']
        if balance < search_cost:
            return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {balance:,} available."}

        try:
            SecondAutomation.run(self, site, query, city, profession, phonecode, start_date, progress_callback=self.updatelead_progress)
            token_deduct = self.consume_token()
            if token_deduct['status'] != 'success':
                return token_deduct
            return {"status": "success", "message": "Search completed! Leads saved to database."}
        except Exception as e:
            return {"status": "error", "message": f"Search failed: {str(e)}"}
        
    def send_email_consent(self, lead_id):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        return send_email_consent(self, lead_id)
    
    def check_email_consent(self, lead_id):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        return check_email_consent(self, lead_id)

    def run_local_search(self, data):
        params = json.loads(data)
        profession = params.get("profession", "realtor")

        # Check token balance before running the search
        search_cost = 2000
        token_check = self.check_tokens()
        if token_check['status'] != 'success':
            return token_check  # Returns error if user not found or Stripe error
        
        balance = token_check['balance']
        if balance < search_cost:
            return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {balance:,} available."}
        try:
            GoogleMapsScraper.run(self, profession=profession, progress_callback=self.updatelocallead_progress)
            token_deduct = self.consume_token()
            if token_deduct['status'] != 'success':
                return token_deduct
            return {"status": "success", "message": "Local business search completed! Leads saved to local database."}
        except Exception as e:
            return {"status": "error", "message": f"Local search failed: {str(e)}"}

    def get_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, email, company, address, number, city, consent_status FROM leads")
        leads = cursor.fetchall()
        conn.close()
        return {"status": "success", "leads": [{"id": l[0], "name": l[1], "email": l[2], "company": l[3], "address": l[4], "number": l[5], "city": l[6], "consent_status": l[7]} for l in leads]}

    def get_local_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, company, address, number, city FROM local_leads")
        leads = cursor.fetchall()
        conn.close()
        return {"status": "success", "leads": [{"id": l[0], "company": l[1], "address": l[2], "number": l[3], "city": l[4]} for l in leads]}

    def send_consent(self, lead_id):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("UPDATE leads SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
        conn.commit()
        conn.close()
        return {"status": "success", "message": f"Consent request sent for lead ID {lead_id}"}
    
    def check_consent(self, lead_id):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT consent_status FROM leads WHERE id = ?", (lead_id,))
        result = cursor.fetchone()
        conn.close()
        if result:
            consent_status = result[0]
            if consent_status == 'Requested':
                return {"status": "success", "message": f"Consent request for lead ID {lead_id} is pending."}
            elif consent_status == 'Accepted':
                return {"status": "success", "message": f"Consent request for lead ID {lead_id} has been accepted."}
            else:
                return {"status": "error", "message": f"Consent request for lead ID {lead_id} has been declined."}
        else:
            return {"status": "error", "message": f"No lead found with ID {lead_id}"}

    def export_leads(self, format):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT name, email, company, address, number, city, consent_status FROM leads")
        leads = cursor.fetchall()
        conn.close()

        base_path = sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
        try:
            if format == 'csv':
                filepath = os.path.join(base_path, "leads_export.csv")
                with open(filepath, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Name', 'Email', 'Company', 'Address', 'Number', 'City', 'Consent Status'])
                    writer.writerows(leads)
                os.startfile(filepath)
                return {"status": "success", "message": f"Leads exported to {filepath}", "filepath": filepath}
            elif format == 'html':
                filepath = os.path.join(base_path, "leads_export.html")
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("<!DOCTYPE html><html><head><title>Leads Export</title><style>")
                    f.write("body { background: #1a202c; color: #e2e8f0; font-family: 'Inter', sans-serif; }")
                    f.write("table { width: 100%; border-collapse: collapse; }")
                    f.write("th, td { padding: 12px; border: 1px solid rgba(255, 255, 255, 0.2); }")
                    f.write("th { background: rgba(255, 255, 255, 0.1); }")
                    f.write("tr:nth-child(even) { background: rgba(255, 255, 255, 0.05); }")
                    f.write("</style></head><body><h1>Leads Export</h1><table>")
                    f.write("<tr><th>Name</th><th>Email</th><th>Company</th><th>Address</th><th>Number</th><th>City</th><th>Consent Status</th></tr>")
                    for lead in leads:
                        f.write(f"<tr><td>{lead[0]}</td><td>{lead[1]}</td><td>{lead[2]}</td><td>{lead[3]}</td><td>{lead[4]}</td><td>{lead[5]}</td><td>{lead[6]}</td></tr>")
                    f.write("</table></body></html>")
                os.startfile(filepath)
                return {"status": "success", "message": f"Leads exported to {filepath}", "filepath": filepath}
        except Exception as e:
            return {"status": "error", "message": f"Export failed: {str(e)}"}

    def export_local_leads(self, format):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT company, address, number, city FROM local_leads")
        leads = cursor.fetchall()
        conn.close()

        base_path = sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
        try:
            if format == 'csv':
                filepath = os.path.join(base_path, "local_leads_export.csv")
                with open(filepath, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Company', 'Address', 'Number', 'City'])
                    writer.writerows(leads)
                os.startfile(filepath)
                return {"status": "success", "message": f"Local leads exported to {filepath}", "filepath": filepath}
            elif format == 'html':
                filepath = os.path.join(base_path, "local_leads_export.html")
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("<!DOCTYPE html><html><head><title>Local Leads Export</title><style>")
                    f.write("body { background: #1a202c; color: #e2e8f0; font-family: 'Inter', sans-serif; }")
                    f.write("table { width: 100%; border-collapse: collapse; }")
                    f.write("th, td { padding: 12px; border: 1px solid rgba(255, 255, 255, 0.2); }")
                    f.write("th { background: rgba(255, 255, 255, 0.1); }")
                    f.write("tr:nth-child(even) { background: rgba(255, 255, 255, 0.05); }")
                    f.write("</style></head><body><h1>Local Leads Export</h1><table>")
                    f.write("<tr><th>Company</th><th>Address</th><th>Number</th><th>City</th></tr>")
                    for lead in leads:
                        f.write(f"<tr><td>{lead[0]}</td><td>{lead[1]}</td><td>{lead[2]}</td><td>{lead[3]}</td></tr>")
                    f.write("</table></body></html>")
                os.startfile(filepath)
                return {"status": "success", "message": f"Local leads exported to {filepath}", "filepath": filepath}
        except Exception as e:
            return {"status": "error", "message": f"Export failed: {str(e)}"}

    def clear_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM leads")
        conn.commit()
        conn.close()
        return {"status": "success", "message": "All leads cleared successfully"}

    def clear_local_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM local_leads")
        conn.commit()
        conn.close()
        return {"status": "success", "message": "All local leads cleared successfully"}

    def delete_selected_leads(self, data):
        try:
            lead_ids = json.loads(data)
            if not lead_ids:
                return {"status": "error", "message": "No leads selected for deletion"}
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.executemany("DELETE FROM leads WHERE id = ?", [(id,) for id in lead_ids])
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Deleted {len(lead_ids)} lead(s) successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Delete failed: {str(e)}"}

    def delete_selected_local_leads(self, data):
        try:
            lead_ids = json.loads(data)
            if not lead_ids:
                return {"status": "error", "message": "No local leads selected for deletion"}
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.executemany("DELETE FROM local_leads WHERE id = ?", [(id,) for id in lead_ids])
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Deleted {len(lead_ids)} local lead(s) successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Delete failed: {str(e)}"}

    def run_instagram_search(self, data):
        params = json.loads(data)
        query = params.get("query")
        city = params.get("city", "")
        continue_search = params.get("continue_search", False)
        if not query:
            return {"status": "error", "message": "Query is required!"}
        
        if not city:
            return {"status": "error", "message": "City is required!"}

        # Check token balance before running the search
        search_cost = 2000
        token_check = self.check_tokens()
        if token_check['status'] != 'success':
            return token_check  # Returns error if user not found or Stripe error
        
        balance = token_check['balance']
        if balance < search_cost:
            return {"status": "error", "message": f"Insufficient tokens. Need {search_cost:,} tokens, but only {balance:,} available."}

        conn = None
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS instagram_search_states (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    query TEXT,
                    city TEXT,
                    last_page INTEGER DEFAULT 0,
                    total_pages INTEGER,
                    UNIQUE(query, city)
                )
            ''')

            login_success = False  # Track login status

            if continue_search:
                cursor.execute("SELECT last_page, total_pages FROM instagram_search_states WHERE query = ? AND city = ?", (query, city))
                result = cursor.fetchone()
                if not result:
                    return {"status": "error", "message": "No previous search found to continue!"}
                
                last_page, total_pages = result
                next_page = last_page + 1
                login_success = ad_generator.run(self, query, city, self.update_progress, start_page=next_page, total_pages=total_pages)
                if not login_success:
                    return {"status": "error", "message": "Instagram login failed. Tokens not deducted."}
                
                token_deduct = self.consume_token()  # Correct: no user_id parameter needed
                if token_deduct['status'] != 'success':
                    return token_deduct
                cursor.execute("UPDATE instagram_search_states SET last_page = ? WHERE query = ? AND city = ?", (next_page, query, city))
            else:
                login_success = ad_generator.run(self, query, city, self.update_progress, start_page=1)
                if not login_success:
                    return {"status": "error", "message": "Instagram login failed. Tokens not deducted."}
                
                token_deduct = self.consume_token()  # Correct: no user_id parameter needed
                if token_deduct['status'] != 'success':
                    return token_deduct
                cursor.execute("INSERT OR REPLACE INTO instagram_search_states (query, city, last_page) VALUES (?, ?, 1)", (query, city))

            conn.commit()
            return {"status": "success", "message": "Instagram leads search completed! Leads saved to database."}
        except Exception as e:
            return {"status": "error", "message": f"Instagram search failed: {str(e)}"}
        finally:
            if conn:
                conn.close()

    def get_instagram_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, username, consent_status FROM instagram_leads")
        leads = cursor.fetchall()
        conn.close()
        return {"status": "success", "leads": [{"id": l[0], "name": l[1], "username": l[2], "consent_status": l[3]} for l in leads]}

    def create_temp_lead(self, data):
        params = json.loads(data)
        email = params.get("email")
        name = params.get("name", "Manual User")

        if not email:
            return {"status": "error", "message": "Email is required!"}

        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("INSERT INTO manual_consents (email, name, consent_status) VALUES (?, ?, 'Pending')", (email, name))
            conn.commit()
            lead_id = cursor.lastrowid
            conn.close()
            return {"status": "success", "lead_id": lead_id}
        except Exception as e:
            return {"status": "error", "message": f"Failed to create temporary lead: {str(e)}"}

    def get_manual_instagram_consents(self):
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, consent_status FROM manual_instagram_consents")
            consents = cursor.fetchall()
            conn.close()
            return {"status": "success", "consents": [{"id": c[0], "username": c[1], "consent_status": c[2]} for c in consents]}
        except Exception as e:
            return {"status": "error", "message": f"Failed to fetch manual Instagram consents: {str(e)}"}

    def get_email_consents(self):
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("SELECT id, email, consent_status FROM manual_consents")
            consents = cursor.fetchall()
            conn.close()
            return {"status": "success", "consents": [{"id": c[0], "email": c[1], "consent_status": c[2]} for c in consents]}
        except Exception as e:
            return {"status": "error", "message": f"Failed to fetch email consents: {str(e)}"}

    def get_instagram_consents(self):
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("SELECT id, username, consent_status FROM instagram_leads")
            consents = cursor.fetchall()
            conn.close()
            return {"status": "success", "consents": [{"id": c[0], "username": c[1], "consent_status": c[2]} for c in consents]}
        except Exception as e:
            return {"status": "error", "message": f"Failed to fetch Instagram consents: {str(e)}"}

    def send_instagram_consent(self, username_or_id):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()

            # Check if the input is a lead_id (integer) or a username (string)
            try:
                lead_id = int(username_or_id)
                # Check both tables to determine the source
                cursor.execute("SELECT username, consent_status FROM instagram_leads WHERE id = ?", (lead_id,))
                result = cursor.fetchone()
                if result:
                    username, current_status = result
                    table_name = "instagram_leads"
                else:
                    cursor.execute("SELECT username, consent_status FROM manual_instagram_consents WHERE id = ?", (lead_id,))
                    result = cursor.fetchone()
                    if not result:
                        conn.close()
                        return {"status": "error", "message": f"No Instagram lead found with ID {lead_id} in any table"}
                    username, current_status = result
                    table_name = "manual_instagram_consents"
                
                # Check if consent can be sent
                if current_status == 'Requested':
                    conn.close()
                    return {"status": "error", "message": f"Consent request already sent for {username}"}
                elif current_status in ['Granted', 'Denied']:
                    conn.close()
                    return {"status": "error", "message": f"Consent already finalized for {username}: {current_status}"}
            except ValueError:
                # It’s a username from the manual input field
                username = username_or_id.strip()
                if not username:
                    conn.close()
                    return {"status": "error", "message": "Username cannot be empty!"}
                
                # For manual entry, always insert a new record in manual_instagram_consents
                cursor.execute("INSERT INTO manual_instagram_consents (username, consent_status) VALUES (?, 'Pending')", 
                            (username,))
                conn.commit()
                lead_id = cursor.lastrowid
                table_name = "manual_instagram_consents"

            # Send the consent request, passing the table_name
            response = send_consent_request(self, lead_id, table_name=table_name)
            
            # Update the consent status in the correct table based on response
            if response["status"] == "success":
                cursor.execute(f"UPDATE {table_name} SET consent_status = 'Requested' WHERE id = ?", (lead_id,))
                conn.commit()
            
            conn.close()
            return response
        except Exception as e:
            conn.close()
            return {"status": "error", "message": f"Failed to send Instagram consent: {str(e)}"}
        
    def check_instagram_consent(self, lead_id):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            
            # Determine the table based on the lead_id
            cursor.execute("SELECT username, consent_status FROM instagram_leads WHERE id = ?", (lead_id,))
            result = cursor.fetchone()
            if result:
                table_name = "instagram_leads"
                username, current_status = result
            else:
                cursor.execute("SELECT username, consent_status FROM manual_instagram_consents WHERE id = ?", (lead_id,))
                result = cursor.fetchone()
                if not result:
                    conn.close()
                    return {"status": "error", "message": f"No Instagram lead found with ID {lead_id}"}
                table_name = "manual_instagram_consents"
                username, current_status = result
            
            # Check consent status and update if necessary
            response = check_consent_request(self, lead_id, table_name=table_name)
            if response["status"] == "success" and response["message"].startswith("Consent status updated"):
                new_status = response["message"].split(": ")[1]
                cursor.execute(f"UPDATE {table_name} SET consent_status = ? WHERE id = ?", (new_status, lead_id))
                conn.commit()
            
            conn.close()
            return response
        except Exception as e:
            conn.close()
            return {"status": "error", "message": f"Failed to check Instagram consent: {str(e)}"}
        
    def check_instagram_approval(self, consent_id):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("SELECT username, consent_status FROM manual_instagram_consents WHERE id = ?", (consent_id,))
            consent = cursor.fetchone()
            if not consent:
                conn.close()
                return {"status": "error", "message": "Consent not found"}

            username, current_status = consent
            if current_status != "Requested":
                conn.close()
                return {"status": "error", "message": "Consent is not in a Requested state"}

            # Call check_consent_request to determine the new status
            response = check_consent_request(self, consent_id, table_name="manual_instagram_consents")
            if response["status"] == "success" and response["message"].startswith("Consent status updated"):
                new_status = response["message"].split(": ")[1]
                cursor.execute("UPDATE manual_instagram_consents SET consent_status = ? WHERE id = ?", (new_status, consent_id))
                conn.commit()

            conn.close()
            return response
        except Exception as e:
            conn.close()
            return {"status": "error", "message": f"Failed to check Instagram approval: {str(e)}"}
        
    def clear_manual_email_consents(self):
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM manual_consents")
            conn.commit()
            conn.close()
            return {"status": "success", "message": "All email consents cleared successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Failed to clear email consents: {str(e)}"}

    def clear_manual_instagram_consents(self):
        try:
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.execute("DELETE FROM manual_instagram_consents")
            conn.commit()
            conn.close()
            return {"status": "success", "message": "All Instagram consents cleared successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Failed to clear Instagram consents: {str(e)}"}

    def delete_selected_manual_email_consents(self, data):
        try:
            consent_ids = json.loads(data)
            if not consent_ids:
                return {"status": "error", "message": "No email consents selected for deletion"}
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.executemany("DELETE FROM manual_consents WHERE id = ?", [(id,) for id in consent_ids])
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Deleted {len(consent_ids)} email consent(s) successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Delete failed: {str(e)}"}

    def delete_selected_manual_instagram_consents(self, data):
        try:
            consent_ids = json.loads(data)
            if not consent_ids:
                return {"status": "error", "message": "No Instagram consents selected for deletion"}
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.executemany("DELETE FROM manual_instagram_consents WHERE id = ?", [(id,) for id in consent_ids])
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Deleted {len(consent_ids)} Instagram consent(s) successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Delete failed: {str(e)}"}
        

    def export_instagram_leads(self, format):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT name, username, consent_status FROM instagram_leads")
        leads = cursor.fetchall()
        conn.close()

        base_path = sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
        try:
            if format == 'csv':
                filepath = os.path.join(base_path, "instagram_leads_export.csv")
                with open(filepath, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f)
                    writer.writerow(['Name', 'Username', 'Consent Status'])
                    writer.writerows(leads)
                os.startfile(filepath)
                return {"status": "success", "message": f"Instagram leads exported to {filepath}", "filepath": filepath}
            elif format == 'html':
                filepath = os.path.join(base_path, "instagram_leads_export.html")
                with open(filepath, "w", encoding="utf-8") as f:
                    f.write("<!DOCTYPE html><html><head><title>Instagram Leads Export</title><style>")
                    f.write("body { background: #1a202c; color: #e2e8f0; font-family: 'Inter', sans-serif; }")
                    f.write("table { width: 100%; border-collapse: collapse; }")
                    f.write("th, td { padding: 12px; border: 1px solid rgba(255, 255, 255, 0.2); }")
                    f.write("th { background: rgba(255, 255, 255, 0.1); }")
                    f.write("tr:nth-child(even) { background: rgba(255, 255, 255, 0.05); }")
                    f.write("</style></head><body><h1>Instagram Leads Export</h1><table>")
                    f.write("<tr><th>Name</th><th>Username</th><th>Consent Status</th></tr>")
                    for lead in leads:
                        f.write(f"<tr><td>{lead[0]}</td><td>{lead[1]}</td><td>{lead[2]}</td></tr>")
                    f.write("</table></body></html>")
                os.startfile(filepath)
                return {"status": "success", "message": f"Instagram leads exported to {filepath}", "filepath": filepath}
        except Exception as e:
            return {"status": "error", "message": f"Export failed: {str(e)}"}

    def clear_instagram_leads(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("DELETE FROM instagram_leads")
        conn.commit()
        conn.close()
        return {"status": "success", "message": "All Instagram leads cleared successfully"}

    def delete_selected_instagram_leads(self, data):
        try:
            lead_ids = json.loads(data)
            if not lead_ids:
                return {"status": "error", "message": "No Instagram leads selected for deletion"}
            conn = self.connect_to_db('leads.db')
            cursor = conn.cursor()
            cursor.executemany("DELETE FROM instagram_leads WHERE id = ?", [(id,) for id in lead_ids])
            conn.commit()
            conn.close()
            return {"status": "success", "message": f"Deleted {len(lead_ids)} Instagram lead(s) successfully"}
        except Exception as e:
            return {"status": "error", "message": f"Delete failed: {str(e)}"}

    def get_instagram_search_states(self):
        conn = self.connect_to_db('leads.db')
        cursor = conn.cursor()
        cursor.execute("SELECT query, city, last_page, total_pages FROM instagram_search_states")
        states = cursor.fetchall()
        conn.close()
        return {"status": "success", "states": [{"query": s[0], "city": s[1], "last_page": s[2], "total_pages": s[3]} for s in states]}

    def chatbot_query(self, data):
        access_check = self.check_access_restriction()
        if access_check['status'] != 'success':
            return access_check
        try:
            return chatbot_query(self, data)  # Pass self as api
        except Exception as e:
            return {"status": "error", "message": f"Chatbot query failed: {str(e)}"}


def get_html_path():
    base_path = sys._MEIPASS if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base_path, "UIautomation.html")

api = API()
html_file = get_html_path()

if os.path.exists(html_file):
    window = webview.create_window("SmartLeads Search", html_file, js_api=api, width=1280, height=720, resizable=True)
    api.set_window(window)
    try:
        webview.start()
    except Exception as e:
        print(f"Error starting webview: {e}")
else:
    print(f"Error: {html_file} not found.")

